
from app.database.connection import Base, engine
from app.database import models

print("Creating missing database tables...")

Base.metadata.create_all(bind=engine)

print("Database migration completed.")

print(
    "Action Item table created:",
    "action_items" in Base.metadata.tables,
)
