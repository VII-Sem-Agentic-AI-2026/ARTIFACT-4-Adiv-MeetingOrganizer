from sqlalchemy import inspect, text

from app.database.connection import engine


inspector = inspect(engine)

columns = [
    column["name"]
    for column in inspector.get_columns("meetings")
]

if "agenda" not in columns:

    with engine.begin() as connection:
        connection.execute(
            text("ALTER TABLE meetings ADD COLUMN agenda TEXT")
        )

    print("Agenda column added successfully.")

else:
    print("Agenda column already exists.")

print("\nCurrent meeting table columns:")

inspector = inspect(engine)

for column in inspector.get_columns("meetings"):
    print("-", column["name"])