from sqlalchemy import Boolean
from datetime import datetime, timezone

from sqlalchemy import (
    Column,
    Integer,
    String,
    Text,
    DateTime,
    ForeignKey,
)

from sqlalchemy.orm import relationship

from app.database.connection import Base


def utc_now():
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), nullable=False)
    email = Column(String(255), unique=True, nullable=False, index=True)
    role = Column(String(50), nullable=False)

    created_at = Column(
        DateTime(timezone=True),
        default=utc_now,
    )


class Meeting(Base):
    __tablename__ = "meetings"

    id = Column(Integer, primary_key=True, index=True)

    meeting_title = Column(String(255), nullable=False)
    purpose = Column(Text, nullable=False)

    preferred_date = Column(String(50), nullable=False)
    preferred_time = Column(String(50), nullable=False)
    duration = Column(Integer, nullable=False)

    participants = Column(Text, nullable=False)

    agenda = Column(Text, nullable=True)
    meeting_notes = Column(Text, nullable=True)
    minutes = Column(Text, nullable=True)

    minutes_status = Column(
        String(30),
        default="not_started",
        nullable=False,
    )

    # Google Calendar integration
    calendar_event_id = Column(
        String(255),
        nullable=True,
        unique=True,
    )

    calendar_event_link = Column(
        Text,
        nullable=True,
    )

    calendar_status = Column(
        String(30),
        default="not_created",
        nullable=False,
    )

    status = Column(
        String(50),
        default="pending",
        nullable=False,
    )

    created_by = Column(
        Integer,
        ForeignKey("users.id"),
        nullable=False,
    )

    created_at = Column(
        DateTime(timezone=True),
        default=utc_now,
    )

    user = relationship("User")

    action_items = relationship(
        "ActionItem",
        back_populates="meeting",
    )


class Approval(Base):
    __tablename__ = "approvals"

    id = Column(Integer, primary_key=True, index=True)

    meeting_id = Column(
        Integer,
        ForeignKey("meetings.id"),
        nullable=False,
    )

    requested_by = Column(
        Integer,
        ForeignKey("users.id"),
        nullable=False,
    )

    approved_by = Column(
        Integer,
        ForeignKey("users.id"),
        nullable=True,
    )

    decision = Column(
        String(50),
        default="pending",
        nullable=False,
    )

    comments = Column(Text, nullable=True)

    created_at = Column(
        DateTime(timezone=True),
        default=utc_now,
    )

    decided_at = Column(
        DateTime(timezone=True),
        nullable=True,
    )

    meeting = relationship("Meeting")


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)

    actor = Column(String(150), nullable=False)
    action = Column(String(100), nullable=False)

    meeting_id = Column(
        Integer,
        ForeignKey("meetings.id"),
        nullable=True,
    )

    details = Column(Text, nullable=True)

    created_at = Column(
        DateTime(timezone=True),
        default=utc_now,
    )


class ActionItem(Base):
    __tablename__ = "action_items"

    id = Column(Integer, primary_key=True, index=True)

    meeting_id = Column(
        Integer,
        ForeignKey("meetings.id"),
        nullable=False,
        index=True,
    )

    task_description = Column(Text, nullable=False)
    owner = Column(String(150), nullable=False)
    deadline = Column(String(100), nullable=True)

    status = Column(
        String(30),
        default="pending",
        nullable=False,
    )

    created_at = Column(
        DateTime(timezone=True),
        default=utc_now,
        nullable=False,
    )

    updated_at = Column(
        DateTime(timezone=True),
        default=utc_now,
        onupdate=utc_now,
        nullable=False,
    )

    updated_by = Column(String(255), nullable=True)

    meeting = relationship(
        "Meeting",
        back_populates="action_items",
    )


class Reminder(Base):
    __tablename__ = "reminders"

    id = Column(Integer, primary_key=True, index=True)

    meeting_id = Column(
        Integer,
        ForeignKey("meetings.id"),
        nullable=True,
        index=True,
    )

    action_item_id = Column(
        Integer,
        ForeignKey("action_items.id"),
        nullable=True,
        index=True,
    )

    reminder_type = Column(String(50), nullable=False)
    recipient = Column(String(500), nullable=True)
    subject = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)

    scheduled_for = Column(DateTime, nullable=False)

    status = Column(
        String(30),
        default="draft",
        nullable=False,
    )

    approved_by = Column(String(255), nullable=True)
    approved_at = Column(DateTime, nullable=True)
    sent_at = Column(DateTime, nullable=True)

    created_at = Column(
        DateTime,
        default=datetime.utcnow,
        nullable=False,
    )


class EmailDelivery(Base):
    __tablename__ = "email_deliveries"

    id = Column(Integer, primary_key=True, index=True)

    meeting_id = Column(
        Integer,
        ForeignKey("meetings.id"),
        nullable=True,
        index=True,
    )

    reminder_id = Column(
        Integer,
        ForeignKey("reminders.id"),
        nullable=True,
        index=True,
    )

    recipient = Column(String(255), nullable=False)
    subject = Column(String(255), nullable=False)
    body = Column(Text, nullable=False)

    gmail_draft_id = Column(
        String(255),
        unique=True,
        nullable=False,
    )

    gmail_message_id = Column(String(255), nullable=True)

    status = Column(
        String(30),
        default="draft",
        nullable=False,
    )

    approved_by = Column(String(255), nullable=True)
    approved_at = Column(DateTime, nullable=True)
    sent_at = Column(DateTime, nullable=True)

    error_message = Column(Text, nullable=True)

    created_at = Column(
        DateTime,
        default=datetime.utcnow,
        nullable=False,
    )

class Resource(Base):
    __tablename__ = "resources"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), nullable=False, unique=True)
    resource_type = Column(String(80), nullable=False)
    location = Column(String(255), nullable=True)
    capacity = Column(Integer, nullable=True)
    is_active = Column(
        Boolean,
        default=True,
        nullable=False,
    )
    created_at = Column(
        DateTime,
        default=datetime.utcnow,
        nullable=False,
    )

    bookings = relationship(
        "ResourceBooking",
        back_populates="resource",
    )


class ResourceBooking(Base):
    __tablename__ = "resource_bookings"

    id = Column(Integer, primary_key=True, index=True)

    meeting_id = Column(
        Integer,
        ForeignKey("meetings.id"),
        nullable=False,
        index=True,
    )

    resource_id = Column(
        Integer,
        ForeignKey("resources.id"),
        nullable=False,
        index=True,
    )

    requested_by = Column(
        Integer,
        ForeignKey("users.id"),
        nullable=False,
    )

    approved_by = Column(
        Integer,
        ForeignKey("users.id"),
        nullable=True,
    )

    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)

    expected_attendees = Column(Integer, nullable=False)

    status = Column(
        String(30),
        default="pending",
        nullable=False,
    )

    comments = Column(Text, nullable=True)

    created_at = Column(
        DateTime,
        default=datetime.utcnow,
        nullable=False,
    )

    decided_at = Column(DateTime, nullable=True)

    resource = relationship(
        "Resource",
        back_populates="bookings",
    )

    meeting = relationship("Meeting")
    requester = relationship("User", foreign_keys=[requested_by])
    approver = relationship("User", foreign_keys=[approved_by])
