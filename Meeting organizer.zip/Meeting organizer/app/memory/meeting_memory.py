import sqlite3
from pathlib import Path


# Locate the project root directory
PROJECT_ROOT = Path(__file__).resolve().parents[2]

# Store the database inside the project's data folder
DATA_DIR = PROJECT_ROOT / "data"
DATA_DIR.mkdir(exist_ok=True)

DB_PATH = DATA_DIR / "meeting_memory.db"


# 1. Create the database and its table
def initialize_database():

    connection = sqlite3.connect(DB_PATH)

    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS meetings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            meeting_title TEXT NOT NULL,
            purpose TEXT,
            meeting_date TEXT,
            participants TEXT,
            decisions TEXT,
            notes TEXT
        )
    """)

    connection.commit()
    connection.close()


# 2. Store a meeting in long-term memory
def save_meeting(
    meeting_title: str,
    purpose: str,
    meeting_date: str,
    participants: str,
    decisions: str,
    notes: str,
):

    connection = sqlite3.connect(DB_PATH)

    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO meetings (
            meeting_title,
            purpose,
            meeting_date,
            participants,
            decisions,
            notes
        )
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        meeting_title,
        purpose,
        meeting_date,
        participants,
        decisions,
        notes,
    ))

    connection.commit()

    meeting_id = cursor.lastrowid

    connection.close()

    return meeting_id


# 3. Retrieve previous meetings using a keyword
def search_meetings(keyword: str):

    connection = sqlite3.connect(DB_PATH)

    connection.row_factory = sqlite3.Row

    cursor = connection.cursor()

    search_term = f"%{keyword}%"

    cursor.execute("""
        SELECT *
        FROM meetings
        WHERE meeting_title LIKE ?
           OR purpose LIKE ?
           OR decisions LIKE ?
           OR notes LIKE ?
        ORDER BY id DESC
    """, (
        search_term,
        search_term,
        search_term,
        search_term,
    ))

    results = [dict(row) for row in cursor.fetchall()]

    connection.close()

    return results


# 4. Retrieve the most recent meetings
def get_recent_meetings(limit: int = 5):

    connection = sqlite3.connect(DB_PATH)

    connection.row_factory = sqlite3.Row

    cursor = connection.cursor()

    cursor.execute("""
        SELECT *
        FROM meetings
        ORDER BY id DESC
        LIMIT ?
    """, (limit,))

    results = [dict(row) for row in cursor.fetchall()]

    connection.close()

    return results


# Initialize the database when this module is imported
initialize_database()