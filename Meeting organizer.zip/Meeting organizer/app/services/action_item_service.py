
from sqlalchemy.orm import Session

from app.database.models import ActionItem, Meeting


VALID_STATUSES = {
    "pending",
    "in_progress",
    "completed",
    "cancelled",
}


def create_action_item(db: Session, item_data: dict):
    meeting = db.query(Meeting).filter(
        Meeting.id == item_data["meeting_id"]
    ).first()

    if not meeting:
        raise ValueError("Meeting not found.")

    if meeting.minutes_status not in {"draft", "approved"}:
        raise ValueError(
            "Minutes must be generated before creating action items."
        )

    action_item = ActionItem(**item_data)

    db.add(action_item)
    db.commit()
    db.refresh(action_item)

    return action_item


def get_action_item(db: Session, action_item_id: int):
    return db.query(ActionItem).filter(
        ActionItem.id == action_item_id
    ).first()


def get_meeting_action_items(db: Session, meeting_id: int):
    return db.query(ActionItem).filter(
        ActionItem.meeting_id == meeting_id
    ).order_by(ActionItem.id.asc()).all()


def get_all_action_items(db: Session):
    return db.query(ActionItem).order_by(
        ActionItem.created_at.desc()
    ).all()


def update_action_item(
    db: Session,
    action_item_id: int,
    update_data: dict,
    updated_by: str,
):
    action_item = get_action_item(db, action_item_id)

    if not action_item:
        raise ValueError("Action item not found.")

    if action_item.status == "completed":
        raise ValueError(
            "Completed action items cannot be modified."
        )

    if action_item.status == "cancelled":
        raise ValueError(
            "Cancelled action items cannot be modified."
        )

    new_status = update_data.get("status")

    if new_status and new_status not in VALID_STATUSES:
        raise ValueError("Invalid action item status.")

    # A completion request requires explicit human confirmation.
    if new_status == "completed":
        if not updated_by:
            raise ValueError(
                "A reviewer identity is required for completion."
            )

    for field, value in update_data.items():
        if value is not None:
            setattr(action_item, field, value)

    action_item.updated_by = updated_by

    db.commit()
    db.refresh(action_item)

    return action_item
