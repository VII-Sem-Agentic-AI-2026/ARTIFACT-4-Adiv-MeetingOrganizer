
from pathlib import Path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build


BASE_DIR = Path(__file__).resolve().parents[2]
CREDENTIALS_FILE = BASE_DIR / "credentials.json"
TOKEN_FILE = BASE_DIR / "token.json"

SCOPES = [
    "https://www.googleapis.com/auth/gmail.compose",
    "https://www.googleapis.com/auth/calendar.freebusy",
    "https://www.googleapis.com/auth/calendar.events",
]


def get_calendar_service():
    credentials = None

    if TOKEN_FILE.exists():
        credentials = Credentials.from_authorized_user_file(
            str(TOKEN_FILE), SCOPES
        )

    if not credentials or not credentials.valid:
        if credentials and credentials.expired and credentials.refresh_token:
            credentials.refresh(Request())
        else:
            if not CREDENTIALS_FILE.exists():
                raise FileNotFoundError(
                    "credentials.json not found in project root."
                )

            flow = InstalledAppFlow.from_client_secrets_file(
                str(CREDENTIALS_FILE), SCOPES
            )
            credentials = flow.run_local_server(port=0)

        TOKEN_FILE.write_text(
            credentials.to_json(), encoding="utf-8"
        )

    return build("calendar", "v3", credentials=credentials)


def check_calendar_availability(
    attendee_emails, start_time, end_time
):
    service = get_calendar_service()

    body = {
    "timeMin": start_time.isoformat(),
    "timeMax": end_time.isoformat(),
    "timeZone": "Asia/Kolkata",
    "items": [
        {"id": email}
        for email in attendee_emails
    ],
}   

    result = service.freebusy().query(body=body).execute()

    calendars = result.get("calendars", {})
    availability = {}

    for email in attendee_emails:
        calendar_data = calendars.get(email, {})
        availability[email] = {
            "busy": calendar_data.get("busy", []),
            "errors": calendar_data.get("errors", []),
        }

    return availability


def create_calendar_event(
    title,
    description,
    start_time,
    end_time,
    attendee_emails,
):
    service = get_calendar_service()

    event = {
        "summary": title,
        "description": description,
        "start": {
            "dateTime": start_time,
        },
        "end": {
            "dateTime": end_time,
        },
        "attendees": [
            {"email": email} for email in attendee_emails
        ],
    }

    created_event = service.events().insert(
        calendarId="primary",
        body=event,
        sendUpdates="all",
    ).execute()

    return {
        "event_id": created_event["id"],
        "event_link": created_event.get("htmlLink"),
        "status": "created",
    }
