
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


# Locate the project root directory.
PROJECT_ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    """
    Central application configuration.

    Values can be loaded from environment variables
    or a .env file.
    """

    APP_NAME: str = "AI Meeting Organizer Agent"

    APP_VERSION: str = "1.0.0"

    DEBUG: bool = True

    DATABASE_URL: str = (
        f"sqlite:///{(PROJECT_ROOT / 'data' / 'meeting_organizer.db').as_posix()}"
    )

    OPENAI_API_KEY: str = ""

    GOOGLE_CLIENT_ID: str = ""

    GOOGLE_CLIENT_SECRET: str = ""

    GOOGLE_REDIRECT_URI: str = (
        "http://localhost:8000/auth/google/callback"
    )

    model_config = SettingsConfigDict(
        env_file=PROJECT_ROOT / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


# Create one shared settings object.
settings = Settings()
