
from typing import TypedDict

from langgraph.graph import StateGraph, END

from app.tools.meeting_tools import check_availability
from app.memory.meeting_memory import search_meetings
from app.skills.agenda_preparation import prepare_agenda
from app.skills.meeting_validation import validate_meeting


class CapstoneMeetingState(TypedDict, total=False):

    # Input
    meeting_title: str
    purpose: str
    participants: list[str]
    preferred_date: str
    preferred_time: str
    duration: int

    # Validation
    validation_errors: list[str]
    request_valid: bool

    # Agent results
    availability: dict
    previous_meetings: list[dict]
    agenda: list[dict]

    # Workflow result
    workflow_status: str
    result_message: str


def validate_request(state: CapstoneMeetingState) -> dict:

    details = {
        "meeting_title": state.get("meeting_title", ""),
        "purpose": state.get("purpose", ""),
        "participants": ", ".join(state.get("participants", [])),
        "preferred_date": state.get("preferred_date", ""),
        "preferred_time": state.get("preferred_time", ""),
        "duration": state.get("duration"),
    }

    result = validate_meeting(details)

    return {
        "validation_errors": result["errors"],
        "request_valid": result["valid"],
    }


def check_participant_availability(
    state: CapstoneMeetingState
) -> dict:

    result = check_availability(
        participants=state.get("participants", []),
    preferred_date=state.get("preferred_date", ""),
    proposed_time=state.get("preferred_time", ""),
    duration_minutes=state.get("duration", 60),
    )

    return {"availability": result}


def retrieve_meeting_memory(
    state: CapstoneMeetingState
) -> dict:

    purpose = state.get("purpose", "")

    previous_meetings = search_meetings(purpose)

    return {"previous_meetings": previous_meetings}


def generate_agenda(state: CapstoneMeetingState) -> dict:

    agenda = prepare_agenda(
        state.get("purpose", ""),
        state.get("duration", 60),
    )

    return {"agenda": agenda}


def route_after_validation(state: CapstoneMeetingState) -> str:

    if state.get("request_valid"):
        return "continue"

    return "stop"


def route_after_availability(state: CapstoneMeetingState) -> str:

    availability = state.get("availability", {})

    if availability.get("available"):
        return "continue"

    return "stop"


def finish_successfully(state: CapstoneMeetingState) -> dict:

    return {
        "workflow_status": "ready_for_review",
        "result_message": (
            "Meeting request validated. "
            "Availability checked and agenda prepared. "
            "Awaiting human approval."
        ),
    }


def finish_with_error(state: CapstoneMeetingState) -> dict:

    return {
        "workflow_status": "needs_attention",
        "result_message": (
            "Meeting request could not proceed. "
            "Review validation errors or participant availability."
        ),
    }


# Build the graph
builder = StateGraph(CapstoneMeetingState)

builder.add_node("validate_request", validate_request)
builder.add_node("check_availability", check_participant_availability)
builder.add_node("retrieve_memory", retrieve_meeting_memory)
builder.add_node("generate_agenda", generate_agenda)
builder.add_node("success", finish_successfully)
builder.add_node("failure", finish_with_error)

builder.set_entry_point("validate_request")

builder.add_conditional_edges(
    "validate_request",
    route_after_validation,
    {
        "continue": "check_availability",
        "stop": "failure",
    },
)

builder.add_conditional_edges(
    "check_availability",
    route_after_availability,
    {
        "continue": "retrieve_memory",
        "stop": "failure",
    },
)

builder.add_edge("retrieve_memory", "generate_agenda")
builder.add_edge("generate_agenda", "success")

builder.add_edge("success", END)
builder.add_edge("failure", END)

capstone_workflow = builder.compile()
