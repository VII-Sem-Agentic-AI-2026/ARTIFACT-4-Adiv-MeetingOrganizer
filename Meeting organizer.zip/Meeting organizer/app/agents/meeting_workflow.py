from app.tools.meeting_tools import check_availability
from typing import TypedDict
from app.memory.meeting_memory import search_meetings
from app.skills.agenda_preparation import prepare_agenda
from langgraph.graph import StateGraph, END

class MeetingWorkflowState(TypedDict, total=False):

    # Meeting information
    meeting_title: str
    purpose: str
    participants: list[str]
    preferred_date: str
    preferred_time: str
    duration: int

    # Validation results
    validation_errors: list[str]
    request_valid: bool

    # Availability results
    availability: dict

    # Memory results
    previous_meetings: list[dict]

    # Agenda results
    agenda: list[dict]

    # Approval results
    approval_status: str
approval_required: bool
approval_decision: str
def validate_meeting_request(
    state: MeetingWorkflowState
) -> dict:

    errors = []

    # Check required meeting information
    required_fields = {
        "meeting_title": "Meeting title",
        "purpose": "Meeting purpose",
        "preferred_date": "Preferred date",
        "preferred_time": "Preferred time",
    }

    for field, label in required_fields.items():

        value = state.get(field)

        if not value or not str(value).strip():
            errors.append(f"{label} is required.")

    # Check participants
    participants = state.get("participants", [])

    if not participants:
        errors.append("At least one participant is required.")

    # Check meeting duration
    duration = state.get("duration")

    if not isinstance(duration, int) or isinstance(duration, bool) or duration <= 0:
        errors.append(
            "Meeting duration must be a positive integer."
        )

    return {
        "validation_errors": errors,
        "request_valid": len(errors) == 0,
    }

def check_meeting_availability(
    state: MeetingWorkflowState
) -> dict:

    participants = state.get("participants", [])
    preferred_time = state.get("preferred_time", "")

    # Use the availability tool from Lab 2
    result = check_availability(
        participants,
        preferred_time,
    )

    return {
        "availability": result,
    }

def retrieve_previous_meetings(
    state: MeetingWorkflowState
) -> dict:

    # Use the meeting purpose as a search keyword
    purpose = state.get("purpose", "")

    # Retrieve matching records from SQLite
    previous_meetings = search_meetings(purpose)

    return {
        "previous_meetings": previous_meetings,
    }

def prepare_meeting_agenda(
    state: MeetingWorkflowState
) -> dict:

    purpose = state.get("purpose", "")
    duration = state.get("duration", 60)

    # Reuse the agenda preparation skill from Lab 3
    agenda = prepare_agenda(
        purpose,
        duration,
    )

    return {
        "agenda": agenda,
    }

def request_human_approval(
    state: MeetingWorkflowState
) -> dict:

    print("\n========================================")
    print("       MEETING APPROVAL REQUIRED")
    print("========================================")

    print("Meeting:", state.get("meeting_title"))
    print("Purpose:", state.get("purpose"))
    print("Participants:", state.get("participants"))
    print("Date:", state.get("preferred_date"))
    print("Time:", state.get("preferred_time"))
    print("Duration:", state.get("duration"), "minutes")

    print("\nPrepared Agenda:")

    for item in state.get("agenda", []):
        print(
            f"- {item['topic']} "
            f"({item['minutes']} minutes)"
        )

    decision = input(
        "\nApprove this meeting request? (yes/no): "
    ).strip().lower()

    if decision == "yes":
        return {
            "approval_required": True,
            "approval_decision": "approved",
            "approval_status": "approved",
        }

    return {
        "approval_required": True,
        "approval_decision": "rejected",
        "approval_status": "rejected",
    }

# Decide what happens after validation
def route_after_validation(
    state: MeetingWorkflowState
) -> str:

    if state.get("request_valid", False):
        return "continue"

    return "stop"


# Decide what happens after availability checking
def route_after_availability(
    state: MeetingWorkflowState
) -> str:

    availability = state.get("availability", {})

    if availability.get("available", False):
        return "continue"

    return "stop"


# Decide what happens after human approval
def route_after_approval(
    state: MeetingWorkflowState
) -> str:

    if state.get("approval_decision") == "approved":
        return "approved"

    return "rejected"

# Create the workflow
workflow = StateGraph(MeetingWorkflowState)


# Register all workflow nodes
workflow.add_node(
    "validate_request",
    validate_meeting_request,
)

workflow.add_node(
    "check_availability",
    check_meeting_availability,
)

workflow.add_node(
    "retrieve_memory",
    retrieve_previous_meetings,
)

workflow.add_node(
    "prepare_agenda",
    prepare_meeting_agenda,
)

workflow.add_node(
    "request_approval",
    request_human_approval,
)


# Set the starting node
workflow.set_entry_point("validate_request")


# Conditional routing after validation
workflow.add_conditional_edges(
    "validate_request",
    route_after_validation,
    {
        "continue": "check_availability",
        "stop": END,
    },
)


# Conditional routing after availability checking
workflow.add_conditional_edges(
    "check_availability",
    route_after_availability,
    {
        "continue": "retrieve_memory",
        "stop": END,
    },
)


# Connect the remaining nodes
workflow.add_edge(
    "retrieve_memory",
    "prepare_agenda",
)

workflow.add_edge(
    "prepare_agenda",
    "request_approval",
)


# Finish after human approval or rejection
workflow.add_conditional_edges(
    "request_approval",
    route_after_approval,
    {
        "approved": END,
        "rejected": END,
    },
)


# Compile the workflow
meeting_workflow = workflow.compile()
