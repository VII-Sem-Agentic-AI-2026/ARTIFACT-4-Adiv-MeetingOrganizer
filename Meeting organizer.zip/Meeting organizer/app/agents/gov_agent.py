
from datetime import datetime, timezone


class GovernanceManager:
    """
    Demonstrates role-based permissions, human approval,
    audit logging, confidentiality and rollback.
    """

    APPROVER_ROLES = {"faculty", "meeting_owner"}

    def __init__(self):
        self.requests = {}
        self.audit_log = []

    def log_event(self, actor, action, request_id, details):
        self.audit_log.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "actor": actor,
            "action": action,
            "request_id": request_id,
            "details": details,
        })

    def request_operation(
        self, request_id, requester, requester_role, operation
    ):
        if request_id in self.requests:
            raise ValueError("Request ID already exists.")

        self.requests[request_id] = {
            "requester": requester,
            "requester_role": requester_role,
            "operation": operation,
            "status": "pending",
            "executed": False,
        }

        self.log_event(
            requester, "REQUEST_CREATED", request_id, operation
        )

        return "Approval required. Operation is pending."

    def decide(self, request_id, approver, approver_role, decision):
        if request_id not in self.requests:
            raise ValueError("Request not found.")

        request = self.requests[request_id]

        if request["status"] != "pending":
            raise PermissionError("Request is not awaiting approval.")

        if approver_role not in self.APPROVER_ROLES:
            self.log_event(
                approver, "APPROVAL_DENIED", request_id,
                "Insufficient permissions"
            )
            raise PermissionError("Only faculty or meeting owners can approve.")

        if approver == request["requester"]:
            raise PermissionError("A requester cannot approve their own request.")

        if decision not in {"approved", "rejected"}:
            raise ValueError("Decision must be approved or rejected.")

        request["status"] = decision

        self.log_event(
            approver, decision.upper(), request_id,
            "Human approval decision recorded"
        )

        return f"Request {decision}."

    def execute_if_approved(self, request_id):
        if request_id not in self.requests:
            raise ValueError("Request not found.")

        request = self.requests[request_id]

        if request["status"] != "approved":
            raise PermissionError(
                "Execution blocked: human approval is required."
            )

        if request["executed"]:
            raise RuntimeError("Operation has already been executed.")

        # Safe simulation: no email or calendar action occurs.
        request["executed"] = True
        request["status"] = "executed"

        self.log_event(
            "SYSTEM", "EXECUTED", request_id,
            f"Simulated operation: {request['operation']}"
        )

        return "Operation executed in simulation mode."

    def rollback(self, request_id, actor, actor_role):
        if request_id not in self.requests:
            raise ValueError("Request not found.")

        request = self.requests[request_id]

        if actor_role not in self.APPROVER_ROLES:
            raise PermissionError("Only authorized reviewers can roll back.")

        if not request["executed"]:
            raise RuntimeError("Nothing has been executed to roll back.")

        request["executed"] = False
        request["status"] = "rolled_back"

        self.log_event(
            actor, "ROLLBACK", request_id,
            "Simulated rollback completed"
        )

        return "Rollback simulated successfully."

    def get_meeting_details(self, user, user_role, details):
        if user_role not in {"scheduler", "faculty", "meeting_owner", "admin"}:
            raise PermissionError("Access denied.")

        visible_details = details.copy()

        if user_role == "scheduler":
            visible_details["confidential_notes"] = "[REDACTED]"

        self.log_event(
            user, "VIEW_DETAILS", "N/A",
            f"Accessed meeting details as {user_role}"
        )

        return visible_details

    def show_audit_log(self):
        return self.audit_log
