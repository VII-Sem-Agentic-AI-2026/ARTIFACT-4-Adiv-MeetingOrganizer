# 1. Define a resilient execution function

def execute_with_retry(
    task,
    max_attempts: int = 3
) -> dict:

    attempts = 0
    errors = []

    while attempts < max_attempts:

        attempts += 1

        print(f"\nAttempt {attempts} of {max_attempts}")

        try:

            # Execute the requested task
            result = task()

            # Validate the result
            if result is None:
                raise ValueError(
                    "Task returned an empty result."
                )

            print("Task completed successfully.")

            return {
                "success": True,
                "result": result,
                "attempts": attempts,
                "errors": errors,
            }

        except Exception as error:

            print("Task failed.")

            # Diagnose and record the error
            error_message = str(error)

            errors.append(error_message)

            print("Diagnosed error:", error_message)

            if attempts < max_attempts:
                print("Retrying task...")
            else:
                print("Retry limit reached.")

    # Return failure after exhausting attempts
    return {
        "success": False,
        "result": None,
        "attempts": attempts,
        "errors": errors,
    }