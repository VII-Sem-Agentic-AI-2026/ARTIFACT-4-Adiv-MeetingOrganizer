
from typing import TypedDict


class MeetingMinutesState(TypedDict):
    meeting_title: str
    meeting_date: str
    participants: list[str]
    meeting_notes: str
    discussion_points: list[str]
    decisions: list[str]
    action_items: list[dict]
    missing_information: list[str]
    minutes_status: str
    draft_minutes: str


def extract_meeting_information(state: MeetingMinutesState):
    notes = state["meeting_notes"]

    discussion_points = []
    decisions = []
    action_items = []
    missing_information = []

    if not notes.strip():
        missing_information.append("Meeting notes were not provided.")

    else:
        for line in notes.splitlines():
            line = line.strip()

            if not line:
                continue

            lower_line = line.lower()

            if lower_line.startswith("discussion:"):
                discussion_points.append(
                    line[len("discussion:"):].strip()
                )

            elif lower_line.startswith("decision:"):
                decisions.append(
                    line[len("decision:"):].strip()
                )

            elif lower_line.startswith("action:"):
                action_text = line[len("action:"):].strip()
                parts = action_text.split("|")

                task = parts[0].strip()
                owner = "Not specified"
                deadline = "Not specified"

                for part in parts[1:]:
                    part = part.strip()

                    if part.lower().startswith("owner:"):
                        owner = part.split(":", 1)[1].strip()

                    elif part.lower().startswith("deadline:"):
                        deadline = part.split(":", 1)[1].strip()

                action_items.append({
                    "task": task,
                    "owner": owner,
                    "deadline": deadline,
                    "status": "Pending confirmation"
                })

    if not discussion_points:
        missing_information.append("No discussion points identified.")

    if not decisions:
        missing_information.append("No decisions explicitly recorded.")

    if not action_items:
        missing_information.append("No action items identified.")

    return {
        "discussion_points": discussion_points,
        "decisions": decisions,
        "action_items": action_items,
        "missing_information": missing_information
    }


def generate_minutes_document(state: MeetingMinutesState):
    lines = [
        "MEETING MINUTES",
        "=" * 50,
        f"Meeting: {state['meeting_title']}",
        f"Date: {state['meeting_date']}",
        f"Participants: {', '.join(state['participants'])}",
        "\nDISCUSSION POINTS",
        "-" * 30
    ]

    for point in state["discussion_points"]:
        lines.append(f"- {point}")

    lines.extend(["\nDECISIONS", "-" * 30])

    for decision in state["decisions"]:
        lines.append(f"- {decision}")

    lines.extend(["\nACTION ITEMS", "-" * 30])

    for index, item in enumerate(state["action_items"], start=1):
        lines.append(f"{index}. Task: {item['task']}")
        lines.append(f"   Owner: {item['owner']}")
        lines.append(f"   Deadline: {item['deadline']}")
        lines.append(f"   Status: {item['status']}")

    lines.extend(["\nMISSING INFORMATION", "-" * 30])

    if state["missing_information"]:
        for item in state["missing_information"]:
            lines.append(f"- {item}")
    else:
        lines.append("None identified.")

    lines.append("\nSTATUS: DRAFT - PENDING HUMAN REVIEW")

    return "\n".join(lines)

def review_meeting_minutes(
    state: MeetingMinutesState,
    decision: str,
    reviewer: str
):
    if decision not in ["approved", "rejected"]:
        raise ValueError(
            "Decision must be approved or rejected."
        )

    if not reviewer.strip():
        raise ValueError("Reviewer identity is required.")

    if decision == "approved":
        state["minutes_status"] = "approved"
    else:
        state["minutes_status"] = "rejected"

    return {
        "minutes_status": state["minutes_status"],
        "reviewer": reviewer,
        "message": (
            "Meeting minutes approved."
            if decision == "approved"
            else "Meeting minutes rejected."
        )
    }
