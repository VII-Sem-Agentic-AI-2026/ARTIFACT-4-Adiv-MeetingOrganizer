from app.memory.meeting_memory import search_meetings


# 1. Retrieve supporting evidence

def retrieve_evidence(query: str) -> list[dict]:

    evidence = search_meetings(query)

    return evidence


# 2. Validate whether a claim is supported

def validate_claim(
    claim: str,
    evidence: list[dict]
) -> dict:

    if not evidence:
        return {
            "supported": False,
            "reason": "No supporting meeting records found."
        }

    # Combine available evidence text
    evidence_text = " ".join(
        str(value)
        for record in evidence
        for value in record.values()
    ).lower()

    # Simple keyword-based evidence check
    claim_words = {
        word.lower().strip(".,!?")
        for word in claim.split()
        if len(word) > 3
    }

    matching_words = [
        word for word in claim_words
        if word in evidence_text
    ]

    support_ratio = (
        len(matching_words) / len(claim_words)
        if claim_words else 0
    )

    supported = support_ratio >= 0.5

    return {
        "supported": supported,
        "matching_words": matching_words,
        "support_ratio": round(support_ratio, 2),
        "reason": (
            "Claim has sufficient keyword overlap with retrieved evidence."
            if supported
            else "Claim does not have sufficient keyword support."
        )
    }


# 3. Generate a grounded response

def generate_grounded_response(
    query: str,
    claim: str
) -> dict:

    evidence = retrieve_evidence(query)

    validation = validate_claim(
        claim,
        evidence
    )

    if validation["supported"]:
        answer = claim
    else:
        answer = (
            "I cannot verify this statement from the "
            "available meeting records."
        )

    return {
        "answer": answer,
        "evidence": evidence,
        "validation": validation,
    }