from datetime import datetime, timedelta
from dateutil import parser


def parse_date(value):
    """Convert a supported date string into a datetime."""
    if not value:
        return None

    try:
        return parser.parse(str(value), fuzzy=False)
    except (ValueError, TypeError, OverflowError):
        return None


def generate_meeting_reminders(meetings, now=None):
    """Prepare reminders for approved meetings happening within seven days."""

    now = now or datetime.now()
    reminders = []

    for meeting in meetings:

        # Never prepare reminders for unapproved meetings.
        if getattr(meeting, "status", None) != "approved":
            continue

        meeting_date = parse_date(meeting.preferred_date)

        if not meeting_date:
            continue

        meeting_time = parse_date(meeting.preferred_time)

        if meeting_time:
            meeting_date = meeting_date.replace(
                hour=meeting_time.hour,
                minute=meeting_time.minute,
            )
        elif meeting_date.hour == 0:
            meeting_date = meeting_date.replace(hour=12)

        if meeting_date <= now:
            continue

        if meeting_date > now + timedelta(days=7):
            continue

        reminder_time = meeting_date - timedelta(hours=24)

        reminders.append({
            "meeting_id": meeting.id,
            "action_item_id": None,
            "reminder_type": "upcoming_meeting",
            "recipient": meeting.participants,
            "subject": f"Upcoming meeting: {meeting.title}",
            "message": (
                f"Reminder: Your meeting '{meeting.title}' "
                f"is scheduled for {meeting_date.strftime('%d %B %Y, %I:%M %p')}."
            ),
            "scheduled_for": reminder_time,
        })

    return reminders


def generate_action_item_reminders(action_items, now=None):
    """Prepare reminders for approved minutes' approaching and overdue action items."""

    now = now or datetime.now()
    reminders = []

    for item in action_items:

        if item.status in ["completed", "cancelled"]:
            continue

        # Only prepare reminders when the related meeting and minutes are approved.
        meeting = getattr(item, "meeting", None)

        if meeting is None:
            continue

        if meeting.status != "approved":
            continue

        if meeting.minutes_status != "approved":
            continue

        deadline = parse_date(item.deadline)

        if not deadline:
            continue

        if deadline.date() < now.date():
            reminder_type = "overdue_action"
            subject = f"Overdue action item: {item.task_description}"
            message = (
                f"Action item '{item.task_description}' is overdue. "
                f"Assigned owner: {item.owner}. "
                f"Deadline: {item.deadline}."
            )

        elif deadline.date() <= (now + timedelta(days=3)).date():
            reminder_type = "action_due"
            subject = f"Action item deadline approaching: {item.task_description}"
            message = (
                f"Action item '{item.task_description}' is approaching its deadline. "
                f"Assigned owner: {item.owner}. "
                f"Deadline: {item.deadline}."
            )

        else:
            continue

        reminders.append({
            "meeting_id": item.meeting_id,
            "action_item_id": item.id,
            "reminder_type": reminder_type,
            "recipient": item.owner,
            "subject": subject,
            "message": message,
            "scheduled_for": now,
        })

    return reminders


def generate_all_reminders(meetings, action_items, now=None):
    """Combine meeting and action-item reminders."""

    return (
        generate_meeting_reminders(meetings, now)
        + generate_action_item_reminders(action_items, now)
    )