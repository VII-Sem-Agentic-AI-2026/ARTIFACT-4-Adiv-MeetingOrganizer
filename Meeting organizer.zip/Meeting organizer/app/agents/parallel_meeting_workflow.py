from typing import TypedDict

from langgraph.graph import StateGraph, START, END

from app.tools.meeting_tools import check_availability
from app.memory.meeting_memory import search_meetings
from app.skills.agenda_preparation import prepare_agenda


# 1. Define shared workflow state

class ParallelMeetingState(TypedDict, total=False):

    meeting_title: str
    purpose: str
    participants: list[str]
    preferred_time: str
    duration: int

    availability: dict
    previous_meetings: list[dict]
    agenda: list[dict]


# 2. Scheduling specialist

def scheduling_agent(state: ParallelMeetingState) -> dict:

    print("\nScheduling agent started.")

    result = check_availability(
        state.get("participants", []),
        state.get("preferred_time", ""),
    )

    print("Scheduling agent completed.")

    return {
        "availability": result
    }


# 3. Memory specialist

def memory_agent(state: ParallelMeetingState) -> dict:

    print("\nMemory agent started.")

    result = search_meetings(
        state.get("purpose", "")
    )

    print("Memory agent completed.")

    return {
        "previous_meetings": result
    }


# 4. Agenda specialist

def agenda_agent(state: ParallelMeetingState) -> dict:

    print("\nAgenda agent started.")

    result = prepare_agenda(
        state.get("purpose", ""),
        state.get("duration", 60),
    )

    print("Agenda agent completed.")

    return {
        "agenda": result
    }


# 5. Merge specialist results

def merge_results(state: ParallelMeetingState) -> dict:

    print("\nAll specialist results received.")

    return {}


# 6. Build the LangGraph workflow

# 6. Build the LangGraph workflow

workflow = StateGraph(ParallelMeetingState)

workflow.add_node("scheduling", scheduling_agent)
workflow.add_node("memory", memory_agent)
workflow.add_node("agenda", agenda_agent)
workflow.add_node("merge", merge_results)

# Start all three specialists independently.
workflow.add_edge(START, "scheduling")
workflow.add_edge(START, "memory")
workflow.add_edge(START, "agenda")

# Wait for all three specialists before merging.
workflow.add_edge("scheduling", "merge")
workflow.add_edge("memory", "merge")
workflow.add_edge("agenda", "merge")

workflow.add_edge("merge", END)

parallel_meeting_workflow = workflow.compile()