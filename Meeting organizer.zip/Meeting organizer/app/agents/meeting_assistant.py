from typing import TypedDict
from langgraph.graph import StateGraph, END

from app.tools.meeting_tools import (
    get_participant_list,
    check_availability,
    calculate_end_time,
)


# 1. Define the agent's state
class MeetingAssistantState(TypedDict, total=False):
    participants_input: str
    preferred_time: str
    duration: int

    participants: list[str]
    availability: dict
    end_time: str
    report: str


# 2. Use the participant-list tool
def prepare_participants(state: MeetingAssistantState):

    participants = get_participant_list(
        state["participants_input"]
    )

    return {
        "participants": participants
    }


# 3. Use the availability-checking tool
def check_meeting_availability(state: MeetingAssistantState):

    result = check_availability(
        state["participants"],
        state["preferred_time"]
    )

    return {
        "availability": result
    }


# 4. Use the time-calculation tool
def calculate_meeting_end(state: MeetingAssistantState):

    end_time = calculate_end_time(
        state["preferred_time"],
        state["duration"]
    )

    return {
        "end_time": end_time
    }


# 5. Prepare the final report
def generate_report(state: MeetingAssistantState):

    availability = state["availability"]

    if availability["available"]:
        availability_message = "All participants are available."
    else:
        unavailable = ", ".join(
            availability["unavailable_participants"]
        )

        availability_message = (
            f"The following participants are busy: {unavailable}"
        )

    report = f"""
MEETING AVAILABILITY REPORT
========================================

Participants:
{chr(10).join("- " + person for person in state["participants"])}

Proposed start time: {state["preferred_time"]}
Proposed end time  : {state["end_time"]}
Duration           : {state["duration"]} minutes

Availability:
{availability_message}

========================================
"""

    return {
        "report": report
    }


# 6. Build the LangGraph workflow
workflow = StateGraph(MeetingAssistantState)

workflow.add_node("prepare_participants", prepare_participants)
workflow.add_node("check_availability", check_meeting_availability)
workflow.add_node("calculate_end_time", calculate_meeting_end)
workflow.add_node("generate_report", generate_report)

workflow.set_entry_point("prepare_participants")

workflow.add_edge("prepare_participants", "check_availability")
workflow.add_edge("check_availability", "calculate_end_time")
workflow.add_edge("calculate_end_time", "generate_report")
workflow.add_edge("generate_report", END)

meeting_assistant = workflow.compile()