
class FacultyMeetingAgent:
    """Specialist for faculty and departmental meetings."""

    def prepare_agenda(self, purpose):
        return {
            "agent": "Faculty Meeting Agent",
            "meeting_type": "Faculty Meeting",
            "purpose": purpose,
            "agenda": [
                "Review of previous meeting minutes",
                "Academic planning and curriculum updates",
                "Faculty workload and responsibilities",
                "Departmental issues and coordination",
                "Decisions and action items",
            ],
        }


class ExaminationCommitteeAgent:
    """Specialist for examination-related meetings."""

    def prepare_agenda(self, purpose):
        return {
            "agent": "Examination Committee Agent",
            "meeting_type": "Examination Committee Meeting",
            "purpose": purpose,
            "agenda": [
                "Review of examination schedule",
                "Question paper preparation and moderation",
                "Examination hall and invigilation arrangements",
                "Evaluation and result-processing timelines",
                "Examination-related issues and action items",
            ],
        }


class ResearchReviewAgent:
    """Specialist for research and project review meetings."""

    def prepare_agenda(self, purpose):
        return {
            "agent": "Research Review Agent",
            "meeting_type": "Research Review Meeting",
            "purpose": purpose,
            "agenda": [
                "Review of research progress",
                "Project milestones and deliverables",
                "Research methodology and findings",
                "Publication and funding updates",
                "Challenges and next action items",
            ],
        }


class AcademicMeetingCoordinator:
    """Routes meeting requests to the appropriate specialist."""

    def __init__(self):
        self.agents = {
            "faculty": FacultyMeetingAgent(),
            "examination": ExaminationCommitteeAgent(),
            "research": ResearchReviewAgent(),
        }

    def organize_meeting(self, meeting_type, purpose):
        if meeting_type not in self.agents:
            raise ValueError(
                f"Unsupported meeting type: {meeting_type}"
            )

        if not purpose.strip():
            raise ValueError("Meeting purpose cannot be empty.")

        specialist = self.agents[meeting_type]

        return specialist.prepare_agenda(purpose)
