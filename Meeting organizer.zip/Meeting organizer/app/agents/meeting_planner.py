
from typing import TypedDict
from langgraph.graph import StateGraph, END


# 1. Define the information our agent needs
class MeetingState(TypedDict, total=False):
    details: dict[str, str]
    missing_fields: list[str]
    clarification_message: str
    plan: str


REQUIRED_FIELDS = {
    "meeting_title": "Meeting title",
    "purpose": "Meeting purpose",
    "participants": "Participants",
    "preferred_date": "Preferred date",
    "preferred_time": "Preferred time",
    "duration": "Meeting duration in minutes",
}


# 2. Agent node: Check for missing information
def validate_request(state: MeetingState):
    details = state.get("details", {})

    missing = [
        field
        for field in REQUIRED_FIELDS
        if not details.get(field, "").strip()
    ]

    return {"missing_fields": missing}


# 3. Agent node: Ask for clarification
def ask_for_information(state: MeetingState):
    missing = state.get("missing_fields", [])

    questions = [
        f"- {REQUIRED_FIELDS[field]}"
        for field in missing
    ]

    message = (
        "I need a little more information "
        "before preparing your meeting plan:\n"
        + "\n".join(questions)
    )

    return {"clarification_message": message}


# 4. Agent node: Prepare the meeting plan
def create_meeting_plan(state: MeetingState):
    details = state.get("details", {})

    participants = [
        person.strip()
        for person in details["participants"].split(",")
        if person.strip()
    ]

    plan = f"""
MEETING PLAN
========================================

Meeting title : {details['meeting_title']}
Purpose       : {details['purpose']}
Date          : {details['preferred_date']}
Preferred time: {details['preferred_time']}
Duration      : {details['duration']} minutes

Participants:
{chr(10).join('- ' + person for person in participants)}

Status: DRAFT - Awaiting scheduler review

========================================
"""

    return {"plan": plan}


# 5. Decide what the agent should do next
def decide_next_step(state: MeetingState):
    if state.get("missing_fields"):
        return "needs_information"

    return "ready"


# 6. Build the LangGraph workflow
workflow = StateGraph(MeetingState)

workflow.add_node("validate_request", validate_request)
workflow.add_node("ask_for_information", ask_for_information)
workflow.add_node("create_meeting_plan", create_meeting_plan)

workflow.set_entry_point("validate_request")

workflow.add_conditional_edges(
    "validate_request",
    decide_next_step,
    {
        "needs_information": "ask_for_information",
        "ready": "create_meeting_plan",
    },
)

workflow.add_edge("ask_for_information", END)
workflow.add_edge("create_meeting_plan", END)

planner_graph = workflow.compile()
