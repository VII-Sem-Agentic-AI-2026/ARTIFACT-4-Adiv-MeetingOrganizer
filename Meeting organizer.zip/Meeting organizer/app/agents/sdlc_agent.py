# 1. SPECIFICATION

def create_specification(
    meeting_title: str,
    purpose: str,
    participants: list[str],
    duration: int,
) -> dict:

    return {
        "meeting_title": meeting_title,
        "purpose": purpose,
        "participants": participants,
        "duration": duration,
        "required_agenda_items": 5,
        "minimum_agenda_items": 3,
    }


# 2. GENERATION

def generate_meeting_output(
    specification: dict
) -> dict:

    from app.skills.agenda_preparation import prepare_agenda

    agenda = prepare_agenda(
        specification["purpose"],
        specification["duration"],
    )

    return {
        "meeting_title": specification["meeting_title"],
        "purpose": specification["purpose"],
        "participants": specification["participants"],
        "duration": specification["duration"],
        "agenda": agenda,
    }


# 3. VALIDATION

def validate_meeting_output(
    output: dict,
    specification: dict
) -> dict:

    errors = []

    if not output.get("meeting_title"):
        errors.append("Meeting title is missing.")

    if not output.get("purpose"):
        errors.append("Meeting purpose is missing.")

    if not output.get("participants"):
        errors.append("Participants are missing.")

    if output.get("duration") != specification["duration"]:
        errors.append("Meeting duration does not match specification.")

    agenda = output.get("agenda", [])

    if len(agenda) < specification["minimum_agenda_items"]:
        errors.append("Agenda contains too few items.")

    total_minutes = sum(
        item.get("minutes", 0)
        for item in agenda
    )

    if total_minutes != specification["duration"]:
        errors.append("Agenda duration does not match meeting duration.")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
    }


# 4. ACCEPTANCE TESTING

def run_acceptance_tests(
    output: dict,
    specification: dict
) -> dict:

    tests = {}

    tests["title_present"] = bool(
        output.get("meeting_title")
    )

    tests["purpose_present"] = bool(
        output.get("purpose")
    )

    tests["participants_present"] = bool(
        output.get("participants")
    )

    tests["agenda_present"] = bool(
        output.get("agenda")
    )

    tests["duration_matches"] = (
        sum(
            item.get("minutes", 0)
            for item in output.get("agenda", [])
        )
        == specification["duration"]
    )

    passed = sum(tests.values())
    total = len(tests)

    return {
        "tests": tests,
        "passed": passed,
        "total": total,
        "all_passed": passed == total,
    }


# 5. COMPLETE SDLC PIPELINE

def execute_sdlc_pipeline(
    meeting_title: str,
    purpose: str,
    participants: list[str],
    duration: int,
) -> dict:

    print("\nSTEP 1: CREATING SPECIFICATION")

    specification = create_specification(
        meeting_title,
        purpose,
        participants,
        duration,
    )

    print("Specification created.")

    print("\nSTEP 2: GENERATING MEETING OUTPUT")

    output = generate_meeting_output(
        specification
    )

    print("Meeting output generated.")

    print("\nSTEP 3: VALIDATING OUTPUT")

    validation = validate_meeting_output(
        output,
        specification,
    )

    print("Validation completed.")

    print("\nSTEP 4: RUNNING ACCEPTANCE TESTS")

    testing = run_acceptance_tests(
        output,
        specification,
    )

    print("Acceptance testing completed.")

    # Release only when both checks pass
    approved = (
        validation["valid"]
        and testing["all_passed"]
    )

    return {
        "specification": specification,
        "output": output,
        "validation": validation,
        "testing": testing,
        "release_approved": approved,
    }