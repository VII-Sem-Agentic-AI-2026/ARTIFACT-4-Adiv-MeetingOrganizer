def format_meeting_plan(
    details: dict,
    participants: list[str],
    agenda: list[dict],
) -> str:
    """
    Format meeting details and agenda into a readable document.
    """

    participant_text = "\n".join(
        f"- {person}" for person in participants
    )

    agenda_text = "\n".join(
        f"- {item['topic']} ({item['minutes']} minutes)"
        for item in agenda
    )

    plan = f"""
MEETING PLAN
================================================

Meeting title : {details['meeting_title']}
Purpose       : {details['purpose']}
Date          : {details['preferred_date']}
Time          : {details['preferred_time']}
Duration      : {details['duration']} minutes

PARTICIPANTS
------------------------------------------------
{participant_text}

MEETING AGENDA
------------------------------------------------
{agenda_text}

STATUS: DRAFT - AWAITING HUMAN APPROVAL

================================================
"""

    return plan