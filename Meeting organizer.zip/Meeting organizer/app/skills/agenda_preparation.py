def prepare_agenda(purpose: str, duration: int) -> list[dict]:
    """
    Prepare a structured meeting agenda based on its purpose
    and duration.
    """

    agenda_topics = [
        ("Opening and meeting objectives", 10),
        ("Review of previous discussions", 20),
        ("Main discussion", 45),
        ("Decisions and action items", 15),
        ("Closing remarks", 10),
    ]

    agenda = []

    allocated_minutes = 0

    for index, (topic, percentage) in enumerate(agenda_topics):

        if index == len(agenda_topics) - 1:
            minutes = duration - allocated_minutes
        else:
            minutes = round(duration * percentage / 100)

        allocated_minutes += minutes

        agenda.append({
            "topic": topic,
            "minutes": minutes,
        })

    return agenda