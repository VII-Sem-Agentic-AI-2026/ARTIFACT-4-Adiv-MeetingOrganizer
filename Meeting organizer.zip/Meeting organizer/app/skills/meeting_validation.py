def validate_meeting(details: dict) -> dict:
    """
    Check whether meeting information is complete and valid.
    """

    required_fields = [
        "meeting_title",
        "purpose",
        "participants",
        "preferred_date",
        "preferred_time",
        "duration",
    ]

    errors = []

    # Check required information
    for field in required_fields:
        value = details.get(field)

        if not value or not str(value).strip():
            errors.append(f"Missing information: {field}")

    # Validate meeting duration
    duration = details.get("duration", "")

    try:
        duration = int(duration)

        if duration <= 0:
            errors.append("Meeting duration must be greater than zero.")

    except (ValueError, TypeError):
        errors.append("Meeting duration must be a valid number.")

    # Validate participants
    participants = [
        person.strip()
        for person in details.get("participants", "").split(",")
        if person.strip()
    ]

    if not participants:
        errors.append("At least one participant is required.")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "participants": participants,
        "duration": duration if isinstance(duration, int) else None,
    }