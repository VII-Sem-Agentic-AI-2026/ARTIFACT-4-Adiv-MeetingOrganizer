
import re
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from app.services.calendar_service import check_calendar_availability


TIMEZONE = ZoneInfo("Asia/Kolkata")


def get_participant_list(participants: str) -> list[str]:
    """Convert comma-separated participant emails into a list."""
    return [
        person.strip()
        for person in participants.split(",")
        if person.strip()
    ]


def check_availability(
    participants: list[str],
    preferred_date: str,
    proposed_time: str,
    duration_minutes: int,
) -> dict:
    """
    Check participant availability using Google Calendar FreeBusy.

    Participants must be email addresses.
    Date format: YYYY-MM-DD
    Time format: HH:MM AM/PM
    """

    if not participants:
        return {
            "available": False,
            "error": "No participant email addresses supplied.",
        }

    try:
        meeting_date = datetime.strptime(
            preferred_date, "%Y-%m-%d"
        ).date()

        # Normalize spaces around the colon and AM/PM.
        normalized_time = re.sub(
            r"\s*:\s*", ":", proposed_time.strip()
        )
        normalized_time = re.sub(
            r"\s+", " ", normalized_time
        )

        meeting_time = datetime.strptime(
            normalized_time.upper(), "%I:%M %p"
        ).time()

        start_time = datetime.combine(
            meeting_date, meeting_time, tzinfo=TIMEZONE
        )

        end_time = start_time + timedelta(
            minutes=duration_minutes
        )

        result = check_calendar_availability(
            attendee_emails=participants,
            start_time=start_time,
            end_time=end_time,
        )

        unavailable = []
        errors = []

        for email, details in result.items():
            if details.get("busy"):
                unavailable.append(email)

            if details.get("errors"):
                errors.append({
                    "email": email,
                    "errors": details["errors"],
                })

        return {
            "available": not unavailable and not errors,
            "unavailable_participants": unavailable,
            "availability_errors": errors,
            "proposed_date": preferred_date,
            "proposed_time": normalized_time,
            "end_time": end_time.strftime("%I:%M %p"),
        }

    except Exception as error:
        return {
            "available": False,
            "error": str(error),
        }


def calculate_end_time(
    start_time: str,
    duration_minutes: int,
) -> str:
    """Calculate meeting end time."""

    normalized_time = re.sub(
        r"\s*:\s*", ":", start_time.strip()
    )
    normalized_time = re.sub(
        r"\s+", " ", normalized_time
    )

    start = datetime.strptime(
        normalized_time.upper(), "%I:%M %p"
    )
    end = start + timedelta(minutes=duration_minutes)

    return end.strftime("%I:%M %p")
