from pydantic import BaseModel, EmailStr


class MeetingEmailDraftRequest(BaseModel):
    recipient: EmailStr

class ReminderEmailDraftRequest(BaseModel):
    recipient: EmailStr