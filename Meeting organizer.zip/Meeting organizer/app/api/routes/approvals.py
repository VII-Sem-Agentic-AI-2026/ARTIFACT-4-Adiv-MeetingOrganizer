import json
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import User, Meeting, Approval, AuditLog
from app.api.schemas import ApprovalDecision


router = APIRouter(
    prefix="/approvals",
    tags=["Approvals"],
)


@router.get("/pending")
def get_pending_approvals(
    db: Session = Depends(get_db),
):

    approvals = (
        db.query(Approval)
        .filter(Approval.decision == "pending")
        .order_by(Approval.id.desc())
        .all()
    )

    results = []

    for approval in approvals:

        meeting = db.query(Meeting).filter(
            Meeting.id == approval.meeting_id
        ).first()

        if meeting:

            results.append({
                "approval_id": approval.id,
                "meeting_id": meeting.id,
                "meeting_title": meeting.meeting_title,
                "purpose": meeting.purpose,
                "preferred_date": meeting.preferred_date,
                "preferred_time": meeting.preferred_time,
                "duration": meeting.duration,
                "participants": meeting.participants,
                "decision": approval.decision,
                "agenda": (
                    json.loads(meeting.agenda)
                    if meeting.agenda
                    else []
                ),
            })

    return results


@router.post("/{approval_id}/decide")
def decide_approval(
    approval_id: int,
    request: ApprovalDecision,
    db: Session = Depends(get_db),
):

    # Temporary development identity.
    # A real authenticated identity must replace this.
    approver = db.query(User).filter(
        User.email == "faculty.test@example.com"
    ).first()

    if not approver:
        raise HTTPException(
            status_code=400,
            detail="Faculty test account not found.",
        )

    if approver.role not in ["faculty", "meeting_owner"]:
        raise HTTPException(
            status_code=403,
            detail="Only faculty or meeting owners can decide approvals.",
        )

    approval = db.query(Approval).filter(
        Approval.id == approval_id
    ).first()

    if not approval:
        raise HTTPException(
            status_code=404,
            detail="Approval request not found.",
        )

    if approval.decision != "pending":
        raise HTTPException(
            status_code=400,
            detail="This approval request has already been decided.",
        )

    if approval.requested_by == approver.id:
        raise HTTPException(
            status_code=403,
            detail="A requester cannot approve their own meeting.",
        )

    meeting = db.query(Meeting).filter(
        Meeting.id == approval.meeting_id
    ).first()

    if not meeting:
        raise HTTPException(
            status_code=404,
            detail="Associated meeting not found.",
        )

    try:
        approval.decision = request.decision
        approval.approved_by = approver.id
        approval.comments = request.comments
        approval.decided_at = datetime.now(timezone.utc)

        meeting.status = request.decision

        audit = AuditLog(
            actor=approver.name,
            action=f"MEETING_{request.decision.upper()}",
            meeting_id=meeting.id,
            details=request.comments or "Approval decision recorded.",
        )

        db.add(audit)
        db.commit()

        return {
            "message": f"Meeting {request.decision} successfully.",
            "approval_id": approval.id,
            "meeting_id": meeting.id,
            "decision": approval.decision,
            "meeting_status": meeting.status,
            "approved_by": approver.name,
        }

    except Exception:
        db.rollback()
        raise