from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import Meeting, Approval, AuditLog
from app.api.calendar_schemas import CalendarMeetingRequest
from app.services.calendar_service import (
    check_calendar_availability,
    create_calendar_event,
)

router = APIRouter(prefix="/calendar", tags=["Google Calendar"])


def get_approved_meeting(meeting_id, db):
    meeting = db.query(Meeting).filter(
        Meeting.id == meeting_id
    ).first()

    if not meeting:
        raise HTTPException(status_code=404, detail="Meeting not found.")

    if meeting.status != "approved":
        raise HTTPException(
            status_code=403,
            detail="Meeting must be approved before calendar operations."
        )

    approval = db.query(Approval).filter(
        Approval.meeting_id == meeting_id,
        Approval.decision == "approved"
    ).first()

    if not approval:
        raise HTTPException(
            status_code=403,
            detail="No approved faculty approval record found."
        )

    return meeting, approval


@router.post("/meetings/{meeting_id}/availability")
def meeting_availability(
    meeting_id: int,
    request: CalendarMeetingRequest,
    db: Session = Depends(get_db),
):
    get_approved_meeting(meeting_id, db)

    try:
        result = check_calendar_availability(
            attendee_emails=[str(email) for email in request.attendee_emails],
            start_time=request.start_time.isoformat(),
            end_time=request.end_time.isoformat(),
        )

        return {
            "meeting_id": meeting_id,
            "availability": result,
        }

    except Exception as error:
        raise HTTPException(
            status_code=502,
            detail=f"Calendar availability check failed: {str(error)}"
        )


@router.post("/meetings/{meeting_id}/create")
def create_approved_calendar_meeting(
    meeting_id: int,
    request: CalendarMeetingRequest,
    db: Session = Depends(get_db),
):
    meeting, approval = get_approved_meeting(meeting_id, db)

    if meeting.calendar_event_id:
        raise HTTPException(
            status_code=409,
            detail="A calendar event already exists for this meeting."
        )

    attendees = [str(email) for email in request.attendee_emails]

    try:
        availability = check_calendar_availability(
            attendee_emails=attendees,
            start_time=request.start_time.isoformat(),
            end_time=request.end_time.isoformat(),
        )

        unavailable = [
            email
            for email, details in availability.items()
            if details.get("busy") or details.get("errors")
        ]

        if unavailable:
            raise HTTPException(
                status_code=409,
                detail={
                    "message": "Some attendee calendars are busy or unavailable.",
                    "attendees": unavailable,
                    "availability": availability,
                },
            )

        event = create_calendar_event(
            title=meeting.meeting_title,
            description=meeting.purpose or "",
            start_time=request.start_time.isoformat(),
            end_time=request.end_time.isoformat(),
            attendee_emails=attendees,
        )

        meeting.calendar_event_id = event["event_id"]
        meeting.calendar_event_link = event.get("event_link")
        meeting.calendar_status = "created"

        db.add(AuditLog(
            actor=str(approval.approved_by),
            action="CALENDAR_EVENT_CREATED",
            meeting_id=meeting.id,
            details=f"Google Calendar event created: {event['event_id']}",
        ))

        db.commit()
        db.refresh(meeting)

        return {
            "meeting_id": meeting.id,
            "calendar_event_id": meeting.calendar_event_id,
            "calendar_event_link": meeting.calendar_event_link,
            "calendar_status": meeting.calendar_status,
        }

    except HTTPException:
        raise
    except Exception as error:
        db.rollback()
        raise HTTPException(
            status_code=502,
            detail=f"Calendar event creation failed: {str(error)}"
        )