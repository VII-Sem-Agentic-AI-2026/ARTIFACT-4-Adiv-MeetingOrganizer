import json
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import User, Meeting, Approval, AuditLog

from app.api.schemas import (
    MeetingCreate,
    MeetingResponse,
    MeetingSubmissionResponse,
)

from app.agents.capstone_workflow import capstone_workflow


router = APIRouter(
    prefix="/meetings",
    tags=["Meetings"],
)


@router.post(
    "/",
    response_model=MeetingSubmissionResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_meeting(
    request: MeetingCreate,
    db: Session = Depends(get_db),
):

    # Temporary development identity.
    # Authentication will replace this later.
    user = db.query(User).filter(
        User.email == "scheduler.test@example.com"
    ).first()

    if not user:
        raise HTTPException(
            status_code=400,
            detail="Test scheduler not found. Create a user first.",
        )

    # 1. Prepare the input for LangGraph.
    workflow_input = {
        "meeting_title": request.meeting_title,
        "purpose": request.purpose,
        "participants": request.participants,
        "preferred_date": request.preferred_date,
        "preferred_time": request.preferred_time,
        "duration": request.duration,
    }

    # 2. Execute the capstone workflow.
    try:
        workflow_result = capstone_workflow.invoke(workflow_input)
    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"Meeting workflow failed: {str(error)}",
        )

    # 3. Stop if validation or availability checks fail.
    if workflow_result.get("workflow_status") != "ready_for_review":
        raise HTTPException(
            status_code=422,
            detail={
                "message": workflow_result.get("result_message"),
                "validation_errors": workflow_result.get(
                    "validation_errors", []
                ),
                "availability": workflow_result.get("availability"),
            },
        )

    # 4. Save the meeting and its approval/audit records.
    try:
        meeting = Meeting(
            meeting_title=request.meeting_title,
            purpose=request.purpose,
            preferred_date=request.preferred_date,
            preferred_time=request.preferred_time,
            duration=request.duration,
            participants=", ".join(request.participants),
            agenda=json.dumps(workflow_result["agenda"]),
            created_by=user.id,
            status="pending",
        )

        db.add(meeting)
        db.flush()

        approval = Approval(
            meeting_id=meeting.id,
            requested_by=user.id,
            decision="pending",
            comments="Awaiting faculty or meeting-owner review.",
        )

        audit = AuditLog(
            actor=user.name,
            action="MEETING_CREATED",
            meeting_id=meeting.id,
            details=(
                "Meeting request passed the LangGraph workflow. "
                "Awaiting human approval."
            ),
        )

        db.add_all([approval, audit])

        db.commit()
        db.refresh(meeting)

    except Exception:
        db.rollback()
        raise

    # 5. Return the saved meeting and workflow results.
    return {
        "id": meeting.id,
        "meeting_title": meeting.meeting_title,
        "purpose": meeting.purpose,
        "preferred_date": meeting.preferred_date,
        "preferred_time": meeting.preferred_time,
        "duration": meeting.duration,
        "participants": meeting.participants,
        "status": meeting.status,
        "workflow_status": workflow_result["workflow_status"],
        "result_message": workflow_result["result_message"],
        "availability": workflow_result["availability"],
        "agenda": workflow_result["agenda"],
        "previous_meetings_count": len(
            workflow_result.get("previous_meetings", [])
        ),
    }


@router.get("/", response_model=list[MeetingResponse])
def list_meetings(
    db: Session = Depends(get_db),
):
    return db.query(Meeting).order_by(
        Meeting.id.desc()
    ).all()


@router.get("/{meeting_id}", response_model=MeetingResponse)
def get_meeting(
    meeting_id: int,
    db: Session = Depends(get_db),
):
    meeting = db.query(Meeting).filter(
        Meeting.id == meeting_id
    ).first()

    if not meeting:
        raise HTTPException(
            status_code=404,
            detail="Meeting not found.",
        )

    return meeting