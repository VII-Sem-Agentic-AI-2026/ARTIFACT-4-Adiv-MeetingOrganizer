
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime

from app.database.models import User

from app.services.gmail_service import (
    create_email_draft,
    send_email_draft,
)
from app.database.models import (
    Meeting,
    Reminder,
    AuditLog,
    EmailDelivery,
)
from app.database.connection import get_db

from app.api.email_schemas import (
    MeetingEmailDraftRequest,
    ReminderEmailDraftRequest,
)

from app.services.gmail_service import create_email_draft


router = APIRouter(prefix="/emails", tags=["Emails"])


@router.post("/meetings/{meeting_id}/draft")
def create_meeting_invitation_draft(
    meeting_id: int,
    request: MeetingEmailDraftRequest,
    db: Session = Depends(get_db),
):
    meeting = db.query(Meeting).filter(
        Meeting.id == meeting_id
    ).first()

    if not meeting:
        raise HTTPException(404, "Meeting not found.")

    if meeting.status != "approved":
        raise HTTPException(
            403,
            "Meeting must be approved before creating an invitation draft."
        )

    subject = f"Meeting Invitation: {meeting.title}"

    body = f"""
Dear Participant,

You are invited to the following meeting.

Meeting: {meeting.title}
Purpose: {meeting.purpose}
Preferred Date: {meeting.preferred_date}
Preferred Time: {meeting.preferred_time}
Duration: {meeting.duration} minutes

Agenda:
{meeting.agenda or "Agenda to be confirmed."}

Regards,
AI Meeting Organizer
"""

    existing = db.query(EmailDelivery).filter(
        EmailDelivery.meeting_id == meeting.id,
        EmailDelivery.reminder_id.is_(None),
        EmailDelivery.recipient == str(request.recipient),
        EmailDelivery.status.in_(["draft", "approved", "sent"]),
    ).first()

    if existing:
        raise HTTPException(
            409,
            "An email record already exists for this meeting and recipient."
        )

    try:
        result = create_email_draft(
            recipient=str(request.recipient),
            subject=subject,
            body=body,
        )

        delivery = EmailDelivery(
            meeting_id=meeting.id,
            reminder_id=None,
            recipient=str(request.recipient),
            subject=subject,
            body=body,
            gmail_draft_id=result["draft_id"],
            gmail_message_id=result["message_id"],
            status="draft",
        )

        db.add(delivery)

        db.add(AuditLog(
            actor="gmail_integration",
            action="MEETING_EMAIL_DRAFT_CREATED",
            meeting_id=meeting.id,
            details=f"Email delivery record created: {result['draft_id']}",
        ))

        db.commit()
        db.refresh(delivery)

        return {
            "message": "Meeting invitation draft created and recorded.",
            "delivery_id": delivery.id,
            "meeting_id": meeting.id,
            "recipient": delivery.recipient,
            **result,
        }

    except Exception as error:
        db.rollback()
        raise HTTPException(
            500,
            detail=f"Could not create or record Gmail draft: {str(error)}",
        )


@router.post("/reminders/{reminder_id}/draft")
def create_reminder_email_draft(
    reminder_id: int,
    request: ReminderEmailDraftRequest,
    db: Session = Depends(get_db),
):
    reminder = db.query(Reminder).filter(
        Reminder.id == reminder_id
    ).first()

    if not reminder:
        raise HTTPException(404, "Reminder not found.")

    if reminder.status != "approved":
        raise HTTPException(
            403,
            "Reminder must be approved before creating an email draft."
        )

    existing = db.query(EmailDelivery).filter(
        EmailDelivery.reminder_id == reminder.id,
        EmailDelivery.recipient == str(request.recipient),
        EmailDelivery.status.in_(["draft", "approved", "sent"]),
    ).first()

    if existing:
        raise HTTPException(
            409,
            "An email record already exists for this reminder and recipient."
        )

    try:
        result = create_email_draft(
            recipient=str(request.recipient),
            subject=reminder.subject,
            body=reminder.message,
        )

        delivery = EmailDelivery(
            meeting_id=reminder.meeting_id,
            reminder_id=reminder.id,
            recipient=str(request.recipient),
            subject=reminder.subject,
            body=reminder.message,
            gmail_draft_id=result["draft_id"],
            gmail_message_id=result["message_id"],
            status="draft",
        )

        db.add(delivery)

        db.add(AuditLog(
            actor="gmail_integration",
            action="REMINDER_EMAIL_DRAFT_CREATED",
            meeting_id=reminder.meeting_id,
            details=f"Email delivery record created: {result['draft_id']}",
        ))

        db.commit()
        db.refresh(delivery)

        return {
            "message": "Reminder email draft created and recorded.",
            "delivery_id": delivery.id,
            "reminder_id": reminder.id,
            "recipient": delivery.recipient,
            **result,
        }

    except Exception as error:
        db.rollback()
        raise HTTPException(
            500,
            detail=f"Could not create or record Gmail draft: {str(error)}",
        )


@router.get("/")
def list_email_deliveries(
    db: Session = Depends(get_db),
):
    return db.query(EmailDelivery).order_by(
        EmailDelivery.created_at.desc()
    ).all()
@router.post("/{delivery_id}/approve")
def approve_email_delivery(
    delivery_id: int,
    approved_by_email: str,
    db: Session = Depends(get_db),
):
    delivery = db.query(EmailDelivery).filter(
        EmailDelivery.id == delivery_id
    ).first()

    if not delivery:
        raise HTTPException(404, "Email delivery record not found.")

    if delivery.status != "draft":
        raise HTTPException(
            400,
            "Only draft emails can be approved."
        )

    user = db.query(User).filter(
        User.email == approved_by_email
    ).first()

    if not user or user.role not in [
        "faculty",
        "meeting_owner",
        "admin",
    ]:
        raise HTTPException(
            403,
            "Only authorized faculty, meeting owners, or admins can approve emails."
        )

    meeting = None

    if delivery.meeting_id is not None:
        meeting = db.query(Meeting).filter(
            Meeting.id == delivery.meeting_id
        ).first()

        if not meeting:
            raise HTTPException(404, "Related meeting not found.")

        if meeting.created_by == user.email:
            raise HTTPException(
                403,
                "The meeting creator cannot approve their own email."
            )

    delivery.status = "approved"
    delivery.approved_by = user.email
    delivery.approved_at = datetime.utcnow()

    db.add(AuditLog(
        actor=user.email,
        action="EMAIL_DELIVERY_APPROVED",
        meeting_id=delivery.meeting_id,
        details=f"Email delivery {delivery.id} approved."
    ))

    db.commit()
    db.refresh(delivery)

    return {
        "message": "Email approved successfully.",
        "delivery_id": delivery.id,
        "status": delivery.status,
        "approved_by": delivery.approved_by,
    }
@router.post("/{delivery_id}/send")
def send_approved_email(
    delivery_id: int,
    db: Session = Depends(get_db),
):
    delivery = db.query(EmailDelivery).filter(
        EmailDelivery.id == delivery_id
    ).first()

    if not delivery:
        raise HTTPException(404, "Email delivery record not found.")

    if delivery.status != "approved":
        raise HTTPException(
            403,
            "Email must be approved before sending."
        )

    try:
        result = send_email_draft(delivery.gmail_draft_id)

        delivery.status = "sent"
        delivery.sent_at = datetime.utcnow()
        delivery.gmail_message_id = result["message_id"]
        delivery.error_message = None

        db.add(AuditLog(
            actor="gmail_integration",
            action="EMAIL_SENT",
            meeting_id=delivery.meeting_id,
            details=(
                f"Email delivery {delivery.id} sent to "
                f"{delivery.recipient}. Gmail message ID: "
                f"{result['message_id']}"
            ),
        ))

        db.commit()
        db.refresh(delivery)

        return {
            "message": "Approved email sent successfully.",
            "delivery_id": delivery.id,
            "recipient": delivery.recipient,
            "status": delivery.status,
            "gmail_message_id": delivery.gmail_message_id,
        }

    except Exception as error:
        db.rollback()

        delivery.error_message = str(error)
        db.commit()

        raise HTTPException(
            status_code=502,
            detail="Gmail sending failed. Check the delivery record before retrying."
        )