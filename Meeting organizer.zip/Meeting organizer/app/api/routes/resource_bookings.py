
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import (
    User,
    Meeting,
    Resource,
    ResourceBooking,
    AuditLog,
)
from app.api.resource_schemas import (
    ResourceCreate,
    ResourceResponse,
    ResourceBookingCreate,
    ResourceBookingDecision,
)

router = APIRouter(
    prefix="/resources",
    tags=["Resource Booking"],
)


def to_utc_naive(value):
    return value.astimezone(timezone.utc).replace(tzinfo=None)


def get_user_by_email(email, db):
    user = db.query(User).filter(User.email == email).first()

    if not user:
        raise HTTPException(
            status_code=404,
            detail="User not found.",
        )

    return user


def check_resource_conflict(
    db, resource_id, start_time, end_time, exclude_id=None
):
    query = db.query(ResourceBooking).filter(
        ResourceBooking.resource_id == resource_id,
        ResourceBooking.status == "approved",
        ResourceBooking.start_time < end_time,
        ResourceBooking.end_time > start_time,
    )

    if exclude_id is not None:
        query = query.filter(ResourceBooking.id != exclude_id)

    return query.first()


@router.post("/", response_model=ResourceResponse)
def create_resource(
    request: ResourceCreate,
    created_by_email: str,
    db: Session = Depends(get_db),
):
    user = get_user_by_email(created_by_email, db)

    if user.role not in ["faculty", "admin"]:
        raise HTTPException(
            status_code=403,
            detail="Only faculty or admins can add resources.",
        )

    existing = db.query(Resource).filter(
        Resource.name == request.name
    ).first()

    if existing:
        raise HTTPException(
            status_code=409,
            detail="A resource with this name already exists.",
        )

    resource = Resource(
        name=request.name,
        resource_type=request.resource_type,
        location=request.location,
        capacity=request.capacity,
    )

    db.add(resource)
    db.add(AuditLog(
        actor=user.email,
        action="RESOURCE_CREATED",
        details=f"Resource created: {request.name}",
    ))

    db.commit()
    db.refresh(resource)

    return resource


@router.get("/", response_model=list[ResourceResponse])
def list_resources(
    db: Session = Depends(get_db),
):
    return db.query(Resource).order_by(Resource.name).all()


@router.post("/bookings")
def request_resource_booking(
    request: ResourceBookingCreate,
    db: Session = Depends(get_db),
):
    requester = get_user_by_email(
        request.requested_by_email, db
    )

    meeting = db.query(Meeting).filter(
        Meeting.id == request.meeting_id
    ).first()

    if not meeting:
        raise HTTPException(
            status_code=404,
            detail="Meeting not found.",
        )

    if meeting.status != "approved":
        raise HTTPException(
            status_code=403,
            detail="Meeting must be approved before requesting a resource.",
        )

    resource = db.query(Resource).filter(
        Resource.id == request.resource_id,
        Resource.is_active.is_(True),
    ).first()

    if not resource:
        raise HTTPException(
            status_code=404,
            detail="Active resource not found.",
        )

    if (
        resource.capacity is not None
        and request.expected_attendees > resource.capacity
    ):
        raise HTTPException(
            status_code=422,
            detail="Expected attendees exceed resource capacity.",
        )

    start = to_utc_naive(request.start_time)
    end = to_utc_naive(request.end_time)

    if start <= datetime.utcnow():
        raise HTTPException(
            status_code=422,
            detail="Booking must be in the future.",
        )

    conflict = check_resource_conflict(
        db, resource.id, start, end
    )

    if conflict:
        raise HTTPException(
            status_code=409,
            detail="Resource is already booked for this time.",
        )

    booking = ResourceBooking(
        meeting_id=meeting.id,
        resource_id=resource.id,
        requested_by=requester.id,
        start_time=start,
        end_time=end,
        expected_attendees=request.expected_attendees,
        status="pending",
    )

    db.add(booking)
    db.add(AuditLog(
        actor=requester.email,
        action="RESOURCE_BOOKING_REQUESTED",
        meeting_id=meeting.id,
        details=f"Resource {resource.name}; booking pending approval.",
    ))

    db.commit()
    db.refresh(booking)

    return {
        "booking_id": booking.id,
        "resource": resource.name,
        "meeting_id": meeting.id,
        "status": booking.status,
        "message": "Resource booking submitted for approval.",
    }


@router.get("/bookings")
def list_resource_bookings(
    db: Session = Depends(get_db),
):
    bookings = db.query(ResourceBooking).order_by(
        ResourceBooking.created_at.desc()
    ).all()

    return [
        {
            "booking_id": booking.id,
            "meeting_id": booking.meeting_id,
            "resource_id": booking.resource_id,
            "resource_name": booking.resource.name,
            "requested_by": booking.requester.email,
            "start_time": booking.start_time,
            "end_time": booking.end_time,
            "expected_attendees": booking.expected_attendees,
            "status": booking.status,
            "approved_by": (
                booking.approver.email if booking.approver else None
            ),
            "comments": booking.comments,
        }
        for booking in bookings
    ]


@router.post("/bookings/{booking_id}/decide")
def decide_resource_booking(
    booking_id: int,
    request: ResourceBookingDecision,
    db: Session = Depends(get_db),
):
    approver = get_user_by_email(
        request.approved_by_email, db
    )

    if approver.role not in ["faculty", "meeting_owner", "admin"]:
        raise HTTPException(
            status_code=403,
            detail="You are not authorised to decide resource bookings.",
        )

    booking = db.query(ResourceBooking).filter(
        ResourceBooking.id == booking_id
    ).first()

    if not booking:
        raise HTTPException(
            status_code=404,
            detail="Resource booking not found.",
        )

    if booking.status != "pending":
        raise HTTPException(
            status_code=409,
            detail="Only pending bookings can be decided.",
        )

    if booking.requested_by == approver.id:
        raise HTTPException(
            status_code=403,
            detail="The requester cannot approve their own booking.",
        )

    if request.decision == "approved":
        conflict = check_resource_conflict(
            db,
            booking.resource_id,
            booking.start_time,
            booking.end_time,
            exclude_id=booking.id,
        )

        if conflict:
            raise HTTPException(
                status_code=409,
                detail="Resource was booked by another approved request.",
            )

    booking.status = request.decision
    booking.approved_by = approver.id
    booking.comments = request.comments
    booking.decided_at = datetime.utcnow()

    db.add(AuditLog(
        actor=approver.email,
        action=f"RESOURCE_BOOKING_{request.decision.upper()}",
        meeting_id=booking.meeting_id,
        details=f"Resource booking ID {booking.id}: {request.comments or 'No comments'}",
    ))

    db.commit()
    db.refresh(booking)

    return {
        "booking_id": booking.id,
        "status": booking.status,
        "approved_by": approver.email,
        "message": f"Resource booking {booking.status}.",
    }
