
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import (
    Meeting,
    AuditLog,
    User,
    ActionItem,
)

from app.agents.minutes.minutes_agent import (
    extract_meeting_information,
    generate_minutes_document,
    review_meeting_minutes,
)


router = APIRouter(
    prefix="/minutes",
    tags=["Meeting Minutes"],
)


class MeetingNotesRequest(BaseModel):
    meeting_notes: str = Field(min_length=10)


class MinutesReviewRequest(BaseModel):
    decision: str = Field(pattern="^(approved|rejected)$")
    reviewer_email: str
    comments: str | None = None


@router.post("/{meeting_id}/generate")
def generate_minutes(
    meeting_id: int,
    request: MeetingNotesRequest,
    db: Session = Depends(get_db),
):

    meeting = db.query(Meeting).filter(
        Meeting.id == meeting_id
    ).first()

    if meeting is None:
        raise HTTPException(
            status_code=404,
            detail="Meeting not found.",
        )

    state = {
        "meeting_title": meeting.meeting_title,
        "meeting_date": meeting.preferred_date,
        "participants": [
            person.strip()
            for person in meeting.participants.split(",")
            if person.strip()
        ],
        "meeting_notes": request.meeting_notes,
        "discussion_points": [],
        "decisions": [],
        "action_items": [],
        "missing_information": [],
        "minutes_status": "draft",
        "draft_minutes": "",
    }

    try:
        state = extract_meeting_information(state)

        draft = generate_minutes_document(state)

        meeting.meeting_notes = request.meeting_notes
        meeting.minutes = draft
        meeting.minutes_status = "draft"

        # Retrieve existing action items for this meeting.
        existing_items = db.query(ActionItem).filter(
            ActionItem.meeting_id == meeting.id
        ).all()

        existing_keys = {
            (
                item.task_description.strip().casefold(),
                item.owner.strip().casefold(),
            )
            for item in existing_items
        }

        created_count = 0

        # Save newly extracted action items without duplicating existing ones.
        for extracted in state["action_items"]:

            task = extracted.get("task", "").strip()
            owner = extracted.get("owner", "Not specified").strip()
            deadline = extracted.get("deadline", "Not specified")

            if not task:
                continue

            item_key = (
                task.casefold(),
                owner.casefold(),
            )

            if item_key in existing_keys:
                continue

            action_item = ActionItem(
                meeting_id=meeting.id,
                task_description=task,
                owner=owner or "Not specified",
                deadline=deadline,
                status="pending",
            )

            db.add(action_item)
            existing_keys.add(item_key)
            created_count += 1

        db.add(
            AuditLog(
                actor="Minutes Agent",
                action="MINUTES_GENERATED",
                meeting_id=meeting.id,
                details=(
                    "Draft minutes generated. "
                    f"{created_count} new action items saved."
                ),
            )
        )

        db.commit()
        db.refresh(meeting)

        return {
            "meeting_id": meeting.id,
            "minutes_status": meeting.minutes_status,
            "draft_minutes": meeting.minutes,
            "discussion_points": state["discussion_points"],
            "decisions": state["decisions"],
            "action_items": state["action_items"],
            "action_items_saved": created_count,
            "missing_information": state["missing_information"],
        }

    except Exception as error:
        db.rollback()

        if isinstance(error, HTTPException):
            raise

        raise HTTPException(
            status_code=500,
            detail=f"Minutes generation failed: {str(error)}",
        )


@router.get("/{meeting_id}")
def get_meeting_minutes(
    meeting_id: int,
    db: Session = Depends(get_db),
):

    meeting = db.query(Meeting).filter(
        Meeting.id == meeting_id
    ).first()

    if meeting is None:
        raise HTTPException(
            status_code=404,
            detail="Meeting not found.",
        )

    if not meeting.minutes:
        raise HTTPException(
            status_code=404,
            detail="Minutes have not been generated.",
        )

    return {
        "meeting_id": meeting.id,
        "meeting_title": meeting.meeting_title,
        "minutes_status": meeting.minutes_status,
        "minutes": meeting.minutes,
        "draft_minutes": meeting.minutes,
    }


@router.post("/{meeting_id}/review")
def review_minutes(
    meeting_id: int,
    request: MinutesReviewRequest,
    db: Session = Depends(get_db),
):

    meeting = db.query(Meeting).filter(
        Meeting.id == meeting_id
    ).first()

    if meeting is None:
        raise HTTPException(
            status_code=404,
            detail="Meeting not found.",
        )

    if not meeting.minutes:
        raise HTTPException(
            status_code=400,
            detail="Generate minutes before reviewing.",
        )

    reviewer = db.query(User).filter(
        User.email == request.reviewer_email
    ).first()

    if reviewer is None or reviewer.role not in [
        "faculty",
        "meeting_owner",
    ]:
        raise HTTPException(
            status_code=403,
            detail="Only faculty or meeting owners can review minutes.",
        )

    if reviewer.id == meeting.created_by:
        raise HTTPException(
            status_code=403,
            detail="The meeting creator cannot review their own minutes.",
        )

    if meeting.minutes_status != "draft":
        raise HTTPException(
            status_code=400,
            detail="Only draft minutes can be reviewed.",
        )

    state = {
        "minutes_status": meeting.minutes_status,
    }

    result = review_meeting_minutes(
        state,
        decision=request.decision,
        reviewer=reviewer.name,
    )

    meeting.minutes_status = result["minutes_status"]

    db.add(
        AuditLog(
            actor=reviewer.email,
            action=f"MINUTES_{request.decision.upper()}",
            meeting_id=meeting.id,
            details=request.comments or result["message"],
        )
    )

    db.commit()

    return {
        "meeting_id": meeting.id,
        "minutes_status": meeting.minutes_status,
        "reviewer": reviewer.name,
        "message": result["message"],
    }
