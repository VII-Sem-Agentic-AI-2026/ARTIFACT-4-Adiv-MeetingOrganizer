
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.connection import get_db
from app.database.models import Meeting, AuditLog, User

from app.api.action_item_schemas import (
    ActionItemCreate,
    ActionItemUpdate,
    ActionItemResponse,
)

from app.services.action_item_service import (
    create_action_item,
    get_action_item,
    get_meeting_action_items,
    get_all_action_items,
    update_action_item,
)


router = APIRouter(
    prefix="/action-items",
    tags=["Action Items"],
)


@router.post("/", response_model=ActionItemResponse, status_code=201)
def create_action_item_endpoint(
    request: ActionItemCreate,
    db: Session = Depends(get_db),
):

    try:
        item = create_action_item(
            db,
            request.model_dump(),
        )

        db.add(
            AuditLog(
                actor="system",
                action="action_item_created",
                meeting_id=item.meeting_id,
                details=f"Created action item #{item.id}: "
                        f"{item.task_description}",
            )
        )

        db.commit()
        db.refresh(item)

        return item

    except ValueError as error:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail=str(error),
        )


@router.get("/", response_model=list[ActionItemResponse])
def list_action_items(
    db: Session = Depends(get_db),
):
    return get_all_action_items(db)


@router.get("/meeting/{meeting_id}", response_model=list[ActionItemResponse])
def list_meeting_action_items(
    meeting_id: int,
    db: Session = Depends(get_db),
):

    meeting = db.query(Meeting).filter(
        Meeting.id == meeting_id
    ).first()

    if not meeting:
        raise HTTPException(
            status_code=404,
            detail="Meeting not found.",
        )

    return get_meeting_action_items(db, meeting_id)


@router.get("/{action_item_id}", response_model=ActionItemResponse)
def retrieve_action_item(
    action_item_id: int,
    db: Session = Depends(get_db),
):

    item = get_action_item(db, action_item_id)

    if not item:
        raise HTTPException(
            status_code=404,
            detail="Action item not found.",
        )

    return item


@router.patch("/{action_item_id}", response_model=ActionItemResponse)
def update_action_item_endpoint(
    action_item_id: int,
    request: ActionItemUpdate,
    updated_by: str,
    db: Session = Depends(get_db),
):

    user = db.query(User).filter(
        User.email == updated_by
    ).first()

    if not user:
        raise HTTPException(
            status_code=403,
            detail="Unknown user.",
        )

    update_data = request.model_dump(exclude_unset=True)

    if not update_data:
        raise HTTPException(
            status_code=400,
            detail="No update fields provided.",
        )

    # Only faculty, meeting owners and admins may update task status.
    if "status" in update_data and user.role not in {
        "faculty",
        "meeting_owner",
        "admin",
    }:
        raise HTTPException(
            status_code=403,
            detail="You are not authorized to change action item status.",
        )

    try:
        item = update_action_item(
            db,
            action_item_id,
            update_data,
            updated_by,
        )

        db.add(
            AuditLog(
                actor=updated_by,
                action="action_item_updated",
                meeting_id=item.meeting_id,
                details=f"Updated action item #{item.id}. "
                        f"Changes: {update_data}",
            )
        )

        db.commit()
        db.refresh(item)

        return item

    except ValueError as error:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail=str(error),
        )
