
from fastapi import FastAPI
from app.api.routes.action_items import router as action_items_router
from app.config import settings
from app.api.routes.emails import router as emails_router
from app.api.routes.meetings import router as meetings_router
from app.api.routes.approvals import router as approvals_router
from app.api.routes.minutes import router as minutes_router
from app.api.routes.calendar import router as calendar_router
from app.api.routes.resource_bookings import router as resource_bookings_router

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Backend API for the AI Meeting Organizer Agent",
)


# Register API routers
app.include_router(meetings_router)
app.include_router(approvals_router)
app.include_router(minutes_router)
app.include_router(action_items_router)
app.include_router(emails_router)
app.include_router(calendar_router)
app.include_router(resource_bookings_router)
@app.get("/")
def home():
    

    return {
        "message": "AI Meeting Organizer Agent API is running.",
        "version": settings.APP_VERSION,
    }


@app.get("/health")
def health_check():

    return {
        "status": "healthy",
    }
