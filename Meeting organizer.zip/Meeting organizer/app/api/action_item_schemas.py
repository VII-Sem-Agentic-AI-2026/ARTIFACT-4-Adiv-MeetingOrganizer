
from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, Field, ConfigDict


ActionItemStatus = Literal[
    "pending",
    "in_progress",
    "completed",
    "cancelled",
]


class ActionItemCreate(BaseModel):

    meeting_id: int = Field(gt=0)

    task_description: str = Field(
        min_length=5,
        max_length=2000,
    )

    owner: str = Field(
        min_length=2,
        max_length=150,
    )

    deadline: Optional[str] = None


class ActionItemUpdate(BaseModel):

    task_description: Optional[str] = Field(
        default=None,
        min_length=5,
        max_length=2000,
    )

    owner: Optional[str] = Field(
        default=None,
        min_length=2,
        max_length=150,
    )

    deadline: Optional[str] = None

    status: Optional[ActionItemStatus] = None


class ActionItemResponse(BaseModel):

    id: int
    meeting_id: int
    task_description: str
    owner: str
    deadline: Optional[str]
    status: str
    created_at: datetime
    updated_at: datetime
    updated_by: Optional[str]

    model_config = ConfigDict(from_attributes=True)
