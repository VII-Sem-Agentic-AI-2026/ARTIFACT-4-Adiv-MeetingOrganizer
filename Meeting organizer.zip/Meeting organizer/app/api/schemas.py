
from pydantic import BaseModel, Field, EmailStr
from typing import Optional


class UserCreate(BaseModel):

    name: str = Field(min_length=2, max_length=150)

    email: EmailStr

    role: str = Field(
        pattern="^(scheduler|faculty|meeting_owner|admin)$"
    )


class MeetingCreate(BaseModel):

    meeting_title: str = Field(min_length=3, max_length=255)

    purpose: str = Field(min_length=5)

    preferred_date: str

    preferred_time: str

    duration: int = Field(gt=0, le=1440)

    participants: list[str] = Field(min_length=1)


class MeetingResponse(BaseModel):

    id: int

    meeting_title: str

    purpose: str

    preferred_date: str

    preferred_time: str

    duration: int

    participants: str

    status: str


class ApprovalDecision(BaseModel):

    decision: str = Field(
        pattern="^(approved|rejected)$"
    )

    comments: Optional[str] = None
class MeetingSubmissionResponse(MeetingResponse):
    workflow_status: str
    result_message: str
    availability: dict
    agenda: list[dict]
    previous_meetings_count: int