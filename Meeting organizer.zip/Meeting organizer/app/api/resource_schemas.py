
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, model_validator


class ResourceCreate(BaseModel):
    name: str
    resource_type: str
    location: str | None = None
    capacity: int | None = Field(default=None, gt=0)


class ResourceResponse(BaseModel):
    id: int
    name: str
    resource_type: str
    location: str | None
    capacity: int | None
    is_active: bool

    class Config:
        from_attributes = True


class ResourceBookingCreate(BaseModel):
    meeting_id: int
    resource_id: int
    requested_by_email: str
    start_time: datetime
    end_time: datetime
    expected_attendees: int = Field(gt=0)

    @model_validator(mode="after")
    def validate_booking(self):
        if self.start_time.tzinfo is None or self.end_time.tzinfo is None:
            raise ValueError("Booking times must include a timezone.")

        if self.end_time <= self.start_time:
            raise ValueError("End time must be after start time.")

        return self


class ResourceBookingDecision(BaseModel):
    approved_by_email: str
    decision: Literal["approved", "rejected"]
    comments: str | None = None
