from datetime import datetime
from pydantic import BaseModel, EmailStr, model_validator


class CalendarMeetingRequest(BaseModel):
    start_time: datetime
    end_time: datetime
    attendee_emails: list[EmailStr]

    @model_validator(mode="after")
    def validate_times(self):
        if self.start_time.tzinfo is None or self.end_time.tzinfo is None:
            raise ValueError("Start and end times must include a timezone.")

        if self.end_time <= self.start_time:
            raise ValueError("End time must be after start time.")

        if not self.attendee_emails:
            raise ValueError("At least one attendee is required.")

        return self