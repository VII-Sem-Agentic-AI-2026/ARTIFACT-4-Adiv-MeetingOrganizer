
from datetime import datetime
import json


class AgentRuntime:

    def __init__(self, max_steps: int = 5):

        self.max_steps = max_steps
        self.current_steps = 0

        self.audit_log = []

        self.checkpoint = {
            "status": "initialized",
            "completed_steps": [],
            "pending_approval": None,
        }

    # 1. Check execution budget
    def check_budget(self):

        if self.current_steps >= self.max_steps:
            raise RuntimeError(
                "Execution budget exceeded."
            )

        self.current_steps += 1

    # 2. Record agent activity
    def record_activity(self, activity: str, result: str):

        entry = {
            "timestamp": datetime.now().isoformat(
                timespec="seconds"
            ),
            "activity": activity,
            "result": result,
        }

        self.audit_log.append(entry)

    # 3. Save execution progress
    def save_checkpoint(self, step: str):

        self.checkpoint["completed_steps"].append(step)

        self.checkpoint["status"] = "in_progress"

    # 4. Request human approval
    def request_approval(self, action: str):

        self.checkpoint["pending_approval"] = action
        self.checkpoint["status"] = "awaiting_approval"

        self.record_activity(
            "Human approval requested",
            action,
        )

        return {
            "approval_required": True,
            "action": action,
            "status": "awaiting_approval",
        }

    # 5. Record approval decision
    def record_approval(self, approved: bool):

        if self.checkpoint["pending_approval"] is None:
            raise RuntimeError(
                "There is no pending approval request."
            )

        action = self.checkpoint["pending_approval"]

        self.checkpoint["pending_approval"] = None

        if approved:
            self.checkpoint["status"] = "approved"

            self.record_activity(
                "Human approval granted",
                action,
            )

        else:
            self.checkpoint["status"] = "rejected"

            self.record_activity(
                "Human approval rejected",
                action,
            )

        return self.checkpoint["status"]

    # 6. Display audit history
    def show_audit_log(self):

        return json.dumps(
            self.audit_log,
            indent=4,
        )

    # 7. Display checkpoint
    def show_checkpoint(self):

        return self.checkpoint
