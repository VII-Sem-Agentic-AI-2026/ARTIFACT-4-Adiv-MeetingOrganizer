import json

from mcp.server import MCPServer

from app.tools.meeting_tools import (
    get_participant_list,
    check_availability,
)

from app.memory.meeting_memory import (
    search_meetings,
    get_recent_meetings,
)


# Create the MCP server
mcp_server = MCPServer(
    "Meeting Organizer Connector",
    instructions=(
        "Provides meeting availability and previous meeting "
        "information to the Meeting Organizer Agent."
    ),
)


# TOOL 1: Check meeting availability
@mcp_server.tool()
def check_meeting_availability(
    participants: str,
    proposed_time: str,
) -> str:
    """
    Check simulated calendar availability for meeting participants.
    """

    participant_list = get_participant_list(participants)

    result = check_availability(
        participant_list,
        proposed_time,
    )

    return json.dumps(result, indent=2)


# TOOL 2: Search previous meetings
@mcp_server.tool()
def search_previous_meetings(keyword: str) -> str:
    """
    Search stored meeting records using a keyword.
    """

    results = search_meetings(keyword)

    return json.dumps(results, indent=2)


# TOOL 3: Retrieve recent meetings
@mcp_server.tool()
def retrieve_recent_meetings(limit: int = 5) -> str:
    """
    Retrieve the most recent meeting records.
    """

    if limit < 1 or limit > 20:
        return "Limit must be between 1 and 20."

    results = get_recent_meetings(limit)

    return json.dumps(results, indent=2)


# RESOURCE: Expose recent meeting history as read-only data
@mcp_server.resource("meeting-memory://recent")
def recent_meeting_memory() -> str:
    """
    Provide recent meeting history as an MCP resource.
    """

    results = get_recent_meetings(5)

    return json.dumps(results, indent=2)


if __name__ == "__main__":
    mcp_server.run()