
import streamlit as st
import requests
from datetime import date

API_URL = "http://127.0.0.1:8000"

st.set_page_config(
    page_title="Meeting Scheduler",
    layout="wide",
)

st.title("AI Meeting Organizer")
st.subheader("Scheduler Dashboard")

st.write(
    "Create meeting requests, monitor approvals, "
    "and prepare meeting minutes."
)

st.divider()

# --------------------------------------------------
# CREATE MEETING REQUEST
# --------------------------------------------------

st.header("Create a Meeting Request")

with st.form("meeting_request_form"):

    meeting_title = st.text_input(
        "Meeting Title",
        placeholder="Faculty Coordination Meeting",
    )

    purpose = st.text_area(
        "Meeting Purpose",
        placeholder="Explain the purpose of the meeting",
    )

    participants = st.text_input(
        "Participants",
        placeholder="Dr. Ravi, Dr. Priya",
    )

    col1, col2, col3 = st.columns(3)

    with col1:
        preferred_date = st.date_input(
            "Preferred Date",
            value=date.today(),
        )

    with col2:
        preferred_time = st.text_input(
        "Preferred Time",
        value="12:00 PM",
    )

    preferred_time = " ".join(preferred_time.split())
    preferred_time = preferred_time.replace(" : ", ":")
    preferred_time = preferred_time.replace(" :", ":")
    preferred_time = preferred_time.replace(": ", ":")
    with col3:
        duration = st.number_input(
            "Duration (minutes)",
            min_value=1,
            max_value=1440,
            value=60,
        )

    submitted = st.form_submit_button(
        "Submit Meeting Request",
        type="primary",
    )

    if submitted:

        participant_list = [
            person.strip()
            for person in participants.split(",")
            if person.strip()
        ]

        if not meeting_title.strip() or not purpose.strip():
            st.error("Please enter the meeting title and purpose.")

        elif not participant_list:
            st.error("Please enter at least one participant.")

        else:

            payload = {
                "meeting_title": meeting_title,
                "purpose": purpose,
                "preferred_date": preferred_date.isoformat(),
                "preferred_time": preferred_time,
                "duration": int(duration),
                "participants": participant_list,
            }

            try:
                response = requests.post(
                    f"{API_URL}/meetings/",
                    json=payload,
                    timeout=30,
                )

                if response.status_code == 201:
                    result = response.json()

                    st.success(
                        f"Meeting request submitted. "
                        f"Meeting ID: {result['id']}"
                    )

                    st.subheader("Workflow Results")
                    st.write("Status:", result["workflow_status"])
                    st.write("Approval Status:", result["status"])

                    st.subheader("Participant Availability")
                    st.json(result["availability"])

                    st.subheader("Generated Agenda")
                    st.table(result["agenda"])

                else:
                    st.error(
                        f"Request failed ({response.status_code})"
                    )
                    st.json(response.json())

            except requests.RequestException as error:
                st.error(f"Backend connection error: {error}")


st.divider()

# --------------------------------------------------
# MEETING HISTORY
# --------------------------------------------------

st.header("Meeting History")

if st.button("Refresh Meeting History"):

    try:
        response = requests.get(
            f"{API_URL}/meetings/",
            timeout=15,
        )

        if response.status_code == 200:
            meetings = response.json()

            if meetings:
                st.dataframe(
                    meetings,
                    use_container_width=True,
                )
            else:
                st.info("No meeting requests found.")

        else:
            st.error("Unable to retrieve meeting history.")

    except requests.RequestException as error:
        st.error(f"Backend connection error: {error}")


st.divider()

# --------------------------------------------------
# MEETING MINUTES
# --------------------------------------------------

st.header("Meeting Minutes Agent")

st.write(
    "Submit meeting notes and generate draft minutes "
    "for faculty review."
)

try:
    response = requests.get(
        f"{API_URL}/meetings/",
        timeout=15,
    )

    if response.status_code == 200:

        meetings = response.json()

        if meetings:

            meeting_options = {
                f"{meeting['id']} - {meeting['meeting_title']} "
                f"({meeting['status']})": meeting["id"]
                for meeting in meetings
            }

            selected_meeting = st.selectbox(
                "Select Meeting",
                options=list(meeting_options.keys()),
            )

            meeting_id = meeting_options[selected_meeting]

            st.subheader("Enter Meeting Notes")

            meeting_notes = st.text_area(
                "Meeting Discussion, Decisions and Action Items",
                height=220,
                placeholder=(
                    "Discussion: Research progress was reviewed.\n"
                    "Decision: Submit the revised paper.\n"
                    "Action: Review the paper | Owner: Dr. Ravi "
                    "| Deadline: 25 November 2026"
                ),
            )

            if st.button("Generate Meeting Minutes"):

                if len(meeting_notes.strip()) < 10:
                    st.warning("Please enter sufficient meeting notes.")

                else:

                    payload = {
                        "meeting_notes": meeting_notes,
                    }

                    try:
                        minutes_response = requests.post(
                            f"{API_URL}/minutes/{meeting_id}/generate",
                            json=payload,
                            timeout=30,
                        )

                        if minutes_response.status_code == 200:

                            result = minutes_response.json()

                            st.success("Draft minutes generated.")

                            st.write(
                                "Minutes Status:",
                                result["minutes_status"],
                            )

                            st.subheader("Generated Minutes")

                            st.text_area(
                                "Draft Minutes",
                                value=result["draft_minutes"],
                                height=400,
                                disabled=True,
                            )

                            st.subheader("Extracted Action Items")
                            st.json(result["action_items"])

                            st.subheader("Missing Information")
                            st.json(result["missing_information"])

                            st.info(
                                "These minutes are drafts. "
                                "Faculty approval is required before publication."
                            )

                        else:
                            st.error(
                                f"Generation failed: "
                                f"{minutes_response.status_code}"
                            )
                            st.json(minutes_response.json())

                    except requests.RequestException as error:
                        st.error(f"Backend connection error: {error}")

        else:
            st.info("Create a meeting before generating minutes.")

    else:
        st.error("Unable to load meetings.")

except requests.RequestException as error:
    st.error(f"Backend connection error: {error}")

st.divider()

# --------------------------------------------------
# ACTION ITEM TRACKER
# --------------------------------------------------

st.header("Action Item Tracker")

st.write(
    "Monitor tasks extracted from meeting minutes, "
    "including their assigned owners, deadlines and progress."
)

try:
    response = requests.get(
        f"{API_URL}/meetings/",
        timeout=15,
    )

    if response.status_code == 200:

        meetings = response.json()

        if meetings:

            meeting_options = {
                f"{meeting['id']} - {meeting['meeting_title']}": meeting["id"]
                for meeting in meetings
            }

            selected_action_meeting = st.selectbox(
                "Select Meeting to View Action Items",
                options=list(meeting_options.keys()),
                key="action_item_meeting_selector",
            )

            action_meeting_id = meeting_options[
                selected_action_meeting
            ]

            if st.button("Load Action Items"):

                try:
                    action_response = requests.get(
                        f"{API_URL}/action-items/meeting/"
                        f"{action_meeting_id}",
                        timeout=15,
                    )

                    if action_response.status_code == 200:

                        st.session_state["loaded_action_items"] = (
                            action_response.json()
                        )

                        st.session_state["loaded_action_meeting_id"] = (
                            action_meeting_id
                        )

                    else:
                        st.error("Unable to retrieve action items.")
                        st.json(action_response.json())

                except requests.RequestException as error:
                    st.error(f"Backend connection error: {error}")

            action_items = st.session_state.get(
                "loaded_action_items",
                [],
            )

            loaded_meeting_id = st.session_state.get(
                "loaded_action_meeting_id"
            )

            if loaded_meeting_id == action_meeting_id:

                if action_items:

                    st.subheader("Action Item Summary")

                    total = len(action_items)

                    pending = sum(
                        item["status"] == "pending"
                        for item in action_items
                    )

                    in_progress = sum(
                        item["status"] == "in_progress"
                        for item in action_items
                    )

                    completed = sum(
                        item["status"] == "completed"
                        for item in action_items
                    )

                    cancelled = sum(
                        item["status"] == "cancelled"
                        for item in action_items
                    )

                    col1, col2, col3, col4, col5 = st.columns(5)

                    col1.metric("Total", total)
                    col2.metric("Pending", pending)
                    col3.metric("In Progress", in_progress)
                    col4.metric("Completed", completed)
                    col5.metric("Cancelled", cancelled)

                    st.subheader("Assigned Tasks")

                    display_items = [
                        {
                            "Task ID": item["id"],
                            "Task": item["task_description"],
                            "Owner": item["owner"],
                            "Deadline": item["deadline"],
                            "Status": item["status"],
                            "Last Updated By": item["updated_by"],
                        }
                        for item in action_items
                    ]

                    st.dataframe(
                        display_items,
                        use_container_width=True,
                        hide_index=True,
                    )

                else:
                    st.info(
                        "No action items found for this meeting. "
                        "Generate meeting minutes containing Action entries first."
                    )

        else:
            st.info("Create a meeting before tracking action items.")

    else:
        st.error("Unable to load meetings.")

except requests.RequestException as error:
    st.error(f"Backend connection error: {error}")
