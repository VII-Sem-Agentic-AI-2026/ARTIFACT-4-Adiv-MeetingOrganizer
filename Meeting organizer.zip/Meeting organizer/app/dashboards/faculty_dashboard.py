
import streamlit as st
import requests

API_URL = "http://127.0.0.1:8000"

st.set_page_config(
    page_title="Faculty Dashboard",
    layout="wide",
)

st.title("AI Meeting Organizer")
st.subheader("Faculty Dashboard")

st.write("Review meeting requests and generated meeting minutes.")

# --------------------------------------------------
# SECTION 1: MEETING REQUEST APPROVAL
# --------------------------------------------------

st.divider()
st.header("Pending Meeting Requests")

if st.button("Refresh Pending Requests"):

    try:
        response = requests.get(
            f"{API_URL}/approvals/pending",
            timeout=15,
        )

        if response.status_code == 200:
            st.session_state["pending_requests"] = response.json()
        else:
            st.error("Unable to retrieve pending requests.")
            st.json(response.json())

    except requests.RequestException as error:
        st.error(f"Backend connection failed: {error}")


pending_requests = st.session_state.get("pending_requests", [])

if pending_requests:

    for meeting in pending_requests:

        with st.expander(
            f"Meeting #{meeting['meeting_id']} - "
            f"{meeting['meeting_title']}"
        ):

            st.write("**Purpose:**", meeting["purpose"])
            st.write("**Date:**", meeting["preferred_date"])
            st.write("**Time:**", meeting["preferred_time"])
            st.write("**Duration:**", meeting["duration"], "minutes")
            st.write("**Participants:**", meeting["participants"])

            st.subheader("Proposed Meeting Agenda")

            agenda = meeting.get("agenda", [])

            if agenda:
                st.table(agenda)
            else:
                st.info("No agenda has been prepared.")

            st.divider()
            st.subheader("Approval Decision")

            comments = st.text_area(
                "Faculty Comments",
                key=f"comments_{meeting['approval_id']}",
                placeholder="Enter comments or suggestions...",
            )

            col1, col2 = st.columns(2)

            with col1:

                if st.button(
                    "Approve Meeting",
                    key=f"approve_{meeting['approval_id']}",
                    type="primary",
                ):

                    payload = {
                        "decision": "approved",
                        "comments": comments,
                    }

                    try:
                        result = requests.post(
                            f"{API_URL}/approvals/"
                            f"{meeting['approval_id']}/decide",
                            json=payload,
                            timeout=15,
                        )

                        if result.status_code == 200:
                            st.success("Meeting approved successfully.")
                            st.session_state.pop("pending_requests", None)
                            st.rerun()
                        else:
                            st.error("Approval failed.")
                            st.json(result.json())

                    except requests.RequestException as error:
                        st.error(f"Backend connection failed: {error}")

            with col2:

                if st.button(
                    "Reject Meeting",
                    key=f"reject_{meeting['approval_id']}",
                ):

                    payload = {
                        "decision": "rejected",
                        "comments": comments,
                    }

                    try:
                        result = requests.post(
                            f"{API_URL}/approvals/"
                            f"{meeting['approval_id']}/decide",
                            json=payload,
                            timeout=15,
                        )

                        if result.status_code == 200:
                            st.warning("Meeting request rejected.")
                            st.session_state.pop("pending_requests", None)
                            st.rerun()
                        else:
                            st.error("Rejection failed.")
                            st.json(result.json())

                    except requests.RequestException as error:
                        st.error(f"Backend connection failed: {error}")

else:
    st.info("Click Refresh Pending Requests to load meeting requests.")


# --------------------------------------------------
# SECTION 2: MEETING MINUTES REVIEW
# --------------------------------------------------

st.divider()
st.header("Meeting Minutes Review")

if st.button("Refresh Meeting Minutes"):

    try:
        response = requests.get(
            f"{API_URL}/meetings/",
            timeout=15,
        )

        if response.status_code == 200:
            st.session_state["minutes_meetings"] = response.json()
        else:
            st.error("Unable to retrieve meetings.")
            st.json(response.json())

    except requests.RequestException as error:
        st.error(f"Backend connection failed: {error}")


minutes_meetings = st.session_state.get("minutes_meetings", [])

if minutes_meetings:

    # Include meetings for which minutes have been generated.
    eligible_meetings = [
        meeting
        for meeting in minutes_meetings
        if meeting.get("status") == "approved"
    ]

    if eligible_meetings:

        meeting_options = {
            f"Meeting #{meeting['id']} - {meeting['meeting_title']}": meeting["id"]
            for meeting in eligible_meetings
        }

        selected_label = st.selectbox(
            "Select an approved meeting",
            options=list(meeting_options.keys()),
        )

        selected_meeting_id = meeting_options[selected_label]

        if st.button("Load Minutes"):

            try:
                response = requests.get(
                    f"{API_URL}/minutes/{selected_meeting_id}",
                    timeout=15,
                )

                if response.status_code == 200:
                    st.session_state["selected_minutes"] = response.json()
                else:
                    st.error("Unable to retrieve meeting minutes.")
                    st.json(response.json())

            except requests.RequestException as error:
                st.error(f"Backend connection failed: {error}")

        minutes_data = st.session_state.get("selected_minutes")

        if (
            minutes_data
            and minutes_data.get("meeting_id") == selected_meeting_id
        ):

            st.subheader("Generated Minutes")

            st.write(
                "**Minutes Status:**",
                minutes_data.get("minutes_status", "Unknown"),
            )

            draft_minutes = minutes_data.get("minutes", "")

            if draft_minutes:
                st.text_area(
                    "Minutes Document",
                    value=draft_minutes,
                    height=350,
                    disabled=True,
                )
            else:
                st.info("Minutes have not been generated for this meeting.")

            current_status = minutes_data.get("minutes_status")

            if current_status == "draft":

                st.divider()
                st.subheader("Faculty Review")

                reviewer_email = st.text_input(
                    "Faculty Email",
                    value="faculty.test@example.com",
                    key=f"reviewer_{selected_meeting_id}",
                )

                review_comments = st.text_area(
                    "Review Comments",
                    key=f"minutes_comments_{selected_meeting_id}",
                    placeholder="Enter corrections or review comments...",
                )

                col1, col2 = st.columns(2)

                with col1:

                    if st.button(
                        "Approve Minutes",
                        key=f"approve_minutes_{selected_meeting_id}",
                        type="primary",
                    ):

                        payload = {
                            "decision": "approved",
                            "reviewer_email": reviewer_email,
                            "comments": review_comments,
                        }

                        try:
                            result = requests.post(
                                f"{API_URL}/minutes/"
                                f"{selected_meeting_id}/review",
                                json=payload,
                                timeout=15,
                            )

                            if result.status_code == 200:
                                st.success("Meeting minutes approved.")
                                st.session_state.pop("selected_minutes", None)
                                st.rerun()
                            else:
                                st.error("Minutes approval failed.")
                                st.json(result.json())

                        except requests.RequestException as error:
                            st.error(f"Backend connection failed: {error}")

                with col2:

                    if st.button(
                        "Reject Minutes",
                        key=f"reject_minutes_{selected_meeting_id}",
                    ):

                        payload = {
                            "decision": "rejected",
                            "reviewer_email": reviewer_email,
                            "comments": review_comments,
                        }

                        try:
                            result = requests.post(
                                f"{API_URL}/minutes/"
                                f"{selected_meeting_id}/review",
                                json=payload,
                                timeout=15,
                            )

                            if result.status_code == 200:
                                st.warning("Meeting minutes rejected.")
                                st.session_state.pop("selected_minutes", None)
                                st.rerun()
                            else:
                                st.error("Minutes rejection failed.")
                                st.json(result.json())

                        except requests.RequestException as error:
                            st.error(f"Backend connection failed: {error}")

            elif current_status == "approved":
                st.success("These meeting minutes have already been approved.")

            elif current_status == "rejected":
                st.warning("These meeting minutes were rejected.")

    else:
        st.info(
            "No approved meetings are available for minutes review."
        )

else:
    st.info("Click Refresh Meeting Minutes to load approved meetings.")

st.divider()

# --------------------------------------------------
# SECTION 3: FACULTY ACTION ITEM MANAGEMENT
# --------------------------------------------------

st.header("Action Item Management")

st.write(
    "Review assigned tasks and update their progress. "
    "Only authorized faculty and meeting owners can change task status."
)

try:
    response = requests.get(
        f"{API_URL}/action-items/",
        timeout=15,
    )

    if response.status_code == 200:

        action_items = response.json()

        if action_items:

            st.subheader("All Meeting Action Items")

            display_items = [
                {
                    "Task ID": item["id"],
                    "Meeting ID": item["meeting_id"],
                    "Task": item["task_description"],
                    "Owner": item["owner"],
                    "Deadline": item["deadline"],
                    "Status": item["status"],
                }
                for item in action_items
            ]

            st.dataframe(
                display_items,
                use_container_width=True,
                hide_index=True,
            )

            st.divider()
            st.subheader("Update Action Item Status")

            item_options = {
                (
                    f"Task #{item['id']} - "
                    f"{item['task_description']} "
                    f"({item['status']})"
                ): item
                for item in action_items
            }

            selected_item_label = st.selectbox(
                "Select Action Item",
                options=list(item_options.keys()),
                key="faculty_action_item_selector",
            )

            selected_item = item_options[selected_item_label]

            st.write(
                "**Assigned Owner:**",
                selected_item["owner"],
            )

            st.write(
                "**Current Status:**",
                selected_item["status"],
            )

            reviewer_email = st.text_input(
                "Faculty Email",
                value="faculty.test@example.com",
                key="action_item_reviewer_email",
            )

            allowed_statuses = [
                "pending",
                "in_progress",
                "completed",
                "cancelled",
            ]

            current_status = selected_item["status"]

            if current_status in ["completed", "cancelled"]:
                st.info(
                    "This action item is locked and cannot be modified."
                )

            else:

                new_status = st.selectbox(
                    "New Status",
                    options=allowed_statuses,
                    index=allowed_statuses.index(current_status),
                    key=f"new_status_{selected_item['id']}",
                )

                confirmation = st.checkbox(
                    "I confirm this status update.",
                    key=f"confirm_action_{selected_item['id']}",
                )

                if st.button(
                    "Update Action Item",
                    key=f"update_action_{selected_item['id']}",
                    type="primary",
                ):

                    if not reviewer_email.strip():
                        st.error("Faculty email is required.")

                    elif not confirmation:
                        st.warning(
                            "Please confirm the status update first."
                        )

                    elif new_status == current_status:
                        st.info("No status change was requested.")

                    else:

                        payload = {
                            "status": new_status,
                        }

                        try:
                            update_response = requests.patch(
                                f"{API_URL}/action-items/"
                                f"{selected_item['id']}",
                                params={
                                    "updated_by": reviewer_email,
                                },
                                json=payload,
                                timeout=15,
                            )

                            if update_response.status_code == 200:

                                st.success(
                                    "Action item status updated successfully."
                                )

                                st.rerun()

                            else:
                                st.error(
                                    "Unable to update action item."
                                )
                                st.json(update_response.json())

                        except requests.RequestException as error:
                            st.error(
                                f"Backend connection error: {error}"
                            )

        else:
            st.info(
                "No action items are currently available."
            )

    else:
        st.error("Unable to retrieve action items.")
        st.json(response.json())

except requests.RequestException as error:
    st.error(f"Backend connection error: {error}")
