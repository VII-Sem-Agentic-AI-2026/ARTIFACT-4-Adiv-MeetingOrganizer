
from app.database.connection import SessionLocal
from app.database.models import User, Meeting, AuditLog


db = SessionLocal()

try:
    # Check whether the test scheduler already exists.
    user = db.query(User).filter(
        User.email == "scheduler.test@example.com"
    ).first()

    # Create the scheduler only if it does not exist.
    if user is None:
        user = User(
            name="Test Scheduler",
            email="scheduler.test@example.com",
            role="scheduler",
        )

        db.add(user)
        db.commit()
        db.refresh(user)

        print("Test scheduler created.")
    else:
        print("Existing test scheduler reused.")

    # Create a test meeting.
    meeting = Meeting(
        meeting_title="Database Integration Test",
        purpose="Testing SQLAlchemy database operations",
        preferred_date="2026-11-20",
        preferred_time="12:00 PM",
        duration=60,
        participants="Dr. Ravi, Dr. Priya",
        created_by=user.id,
    )

    db.add(meeting)
    db.flush()

    # Record an audit event.
    event = AuditLog(
        actor="Test Scheduler",
        action="MEETING_CREATED",
        meeting_id=meeting.id,
        details="Test meeting created successfully.",
    )

    db.add(event)
    db.commit()
    db.refresh(meeting)

    print("\nDatabase operations successful!")
    print("User ID:", user.id)
    print("Meeting ID:", meeting.id)
    print("Meeting title:", meeting.meeting_title)
    print("Meeting status:", meeting.status)
    print("Minutes status:", meeting.minutes_status)

except Exception:
    db.rollback()
    raise

finally:
    db.close()
