from sqlalchemy import inspect, text

from app.database.connection import engine

columns = {
    "calendar_event_id": "VARCHAR(255)",
    "calendar_event_link": "TEXT",
    "calendar_status": "VARCHAR(30) NOT NULL DEFAULT 'not_created'",
}

inspector = inspect(engine)
existing = {
    column["name"]
    for column in inspector.get_columns("meetings")
}

with engine.begin() as connection:
    for name, sql_type in columns.items():
        if name not in existing:
            connection.execute(
                text(f"ALTER TABLE meetings ADD COLUMN {name} {sql_type}")
            )
            print(f"Added: {name}")
        else:
            print(f"Already exists: {name}")

print("Calendar database migration completed.")