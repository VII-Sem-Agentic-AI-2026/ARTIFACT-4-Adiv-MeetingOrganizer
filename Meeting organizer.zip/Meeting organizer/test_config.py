from app.config import settings


print("Application:", settings.APP_NAME)
print("Version:", settings.APP_VERSION)
print("Debug mode:", settings.DEBUG)
print("Database:", settings.DATABASE_URL)

print("\nConfiguration loaded successfully!")