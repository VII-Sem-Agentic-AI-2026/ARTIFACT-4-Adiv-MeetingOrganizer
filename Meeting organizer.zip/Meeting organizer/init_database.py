from app.database.connection import Base, engine

# Import models so SQLAlchemy registers all tables.
from app.database import models


def initialize_database():

    Base.metadata.create_all(bind=engine)

    print("Database initialized successfully!")

    print("\nCreated tables:")

    for table_name in Base.metadata.tables:
        print("-", table_name)


if __name__ == "__main__":
    initialize_database()