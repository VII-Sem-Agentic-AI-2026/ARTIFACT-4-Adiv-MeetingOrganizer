
from app.services.gmail_service import create_email_draft


recipient = input(
    "Enter your own Gmail address: "
).strip()

result = create_email_draft(
    recipient=recipient,
    subject="Meeting Organizer Agent - Gmail Test",
    body=(
        "This is a test email draft created by "
        "the AI Meeting Organizer Agent.\n\n"
        "No email has been sent."
    )
)

print("\nGmail draft created successfully.")
print(result)
