
from app.database.connection import SessionLocal
from app.database.models import Meeting, Approval, AuditLog

db = SessionLocal()

try:
    meeting = (
        db.query(Meeting)
        .order_by(Meeting.id.desc())
        .first()
    )

    if not meeting:
        print("No meeting found.")
    else:
        print("\n--- MEETING RECORD ---")
        print("Meeting ID:", meeting.id)
        print("Title:", meeting.meeting_title)
        print("Status:", meeting.status)

        approval = (
            db.query(Approval)
            .filter(Approval.meeting_id == meeting.id)
            .first()
        )

        print("\n--- APPROVAL RECORD ---")

        if approval:
            print("Approval ID:", approval.id)
            print("Meeting ID:", approval.meeting_id)
            print("Decision:", approval.decision)
            print("Requested By:", approval.requested_by)
        else:
            print("Approval record not found.")

        audit = (
            db.query(AuditLog)
            .filter(AuditLog.meeting_id == meeting.id)
            .order_by(AuditLog.id.desc())
            .first()
        )

        print("\n--- AUDIT RECORD ---")

        if audit:
            print("Audit ID:", audit.id)
            print("Action:", audit.action)
            print("Actor:", audit.actor)
            print("Details:", audit.details)
        else:
            print("Audit record not found.")

finally:
    db.close()
