from datetime import datetime, timedelta

from app.services.calendar_service import (
    get_calendar_service,
    check_calendar_availability,
)

service = get_calendar_service()

print("Google Calendar connection successful.")

start = datetime.now().astimezone() + timedelta(days=1)
start = start.replace(minute=0, second=0, microsecond=0)
end = start + timedelta(hours=1)

result = check_calendar_availability(
    attendee_emails=["01fe23bci068@kletech.ac.in"],
    start_time=start.isoformat(),
    end_time=end.isoformat(),
)

print("Availability result:")
print(result)