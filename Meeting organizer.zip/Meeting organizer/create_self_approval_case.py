
from app.database.connection import SessionLocal
from app.database.models import User, Meeting, Approval

db = SessionLocal()

try:
    faculty = db.query(User).filter(
        User.email == "faculty.test@example.com"
    ).first()

    if not faculty:
        raise Exception("Faculty test account not found.")

    meeting = Meeting(
        meeting_title="Self Approval Security Test",
        purpose="Verify that requesters cannot approve their own meetings.",
        preferred_date="2026-11-25",
        preferred_time="04:00 PM",
        duration=30,
        participants="Dr. Ravi, Dr. Priya",
        created_by=faculty.id,
        status="pending",
    )

    db.add(meeting)
    db.flush()

    approval = Approval(
        meeting_id=meeting.id,
        requested_by=faculty.id,
        decision="pending",
        comments="Self-approval security test.",
    )

    db.add(approval)
    db.commit()

    print("Test case created.")
    print("Faculty ID:", faculty.id)
    print("Meeting ID:", meeting.id)
    print("Approval ID:", approval.id)
    print("Requester ID:", approval.requested_by)

except Exception:
    db.rollback()
    raise

finally:
    db.close()
