
from app.database.connection import SessionLocal
from app.database.models import User

db = SessionLocal()

try:
    email = "faculty.test@example.com"

    faculty = (
        db.query(User)
        .filter(User.email == email)
        .first()
    )

    if faculty:
        print("Faculty account already exists.")
        print("User ID:", faculty.id)
        print("Role:", faculty.role)

    else:
        faculty = User(
            name="Test Faculty",
            email=email,
            role="faculty",
        )

        db.add(faculty)
        db.commit()
        db.refresh(faculty)

        print("Faculty account created successfully.")
        print("User ID:", faculty.id)
        print("Name:", faculty.name)
        print("Email:", faculty.email)
        print("Role:", faculty.role)

finally:
    db.close()
