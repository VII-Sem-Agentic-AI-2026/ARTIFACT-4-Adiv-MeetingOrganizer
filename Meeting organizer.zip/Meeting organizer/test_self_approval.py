from app.database.connection import SessionLocal
from app.database.models import User, Meeting, Approval

db = SessionLocal()

try:
    scheduler = db.query(User).filter(
        User.email == "scheduler.test@example.com"
    ).first()

    print("Scheduler ID:", scheduler.id)

    meetings = (
        db.query(Meeting)
        .filter(Meeting.created_by == scheduler.id)
        .order_by(Meeting.id.desc())
        .all()
    )

    for meeting in meetings:
        print("\nMeeting ID:", meeting.id)
        print("Title:", meeting.meeting_title)
        print("Status:", meeting.status)

        approval = db.query(Approval).filter(
            Approval.meeting_id == meeting.id
        ).first()

        if approval:
            print("Approval ID:", approval.id)
            print("Decision:", approval.decision)
            print("Requested by:", approval.requested_by)
        else:
            print("No approval record found.")

finally:
    db.close()