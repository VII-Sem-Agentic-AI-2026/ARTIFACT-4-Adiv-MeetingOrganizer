import sqlite3

from app.config import settings

database_url = settings.DATABASE_URL
database_path = database_url.replace("sqlite:///", "")

connection = sqlite3.connect(database_path)
cursor = connection.cursor()

columns_to_add = {
    "meeting_notes": "TEXT",
    "minutes": "TEXT",
    "minutes_status": "VARCHAR(30) NOT NULL DEFAULT 'not_started'",
}

cursor.execute("PRAGMA table_info(meetings)")
existing_columns = {
    column[1] for column in cursor.fetchall()
}

for column_name, column_type in columns_to_add.items():

    if column_name not in existing_columns:

        cursor.execute(
            f"ALTER TABLE meetings ADD COLUMN "
            f"{column_name} {column_type}"
        )

        print(f"Added column: {column_name}")

    else:
        print(f"Column already exists: {column_name}")

connection.commit()
connection.close()

print("\nDatabase migration completed.")