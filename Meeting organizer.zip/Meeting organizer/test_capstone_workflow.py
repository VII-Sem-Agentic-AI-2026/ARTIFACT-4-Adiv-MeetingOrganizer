
from app.agents.capstone_workflow import capstone_workflow


meeting_request = {
    "meeting_title": "Faculty Coordination Meeting",
    "purpose": "Discuss semester planning and academic activities",
    "participants": ["Dr. Ravi", "Dr. Priya"],
    "preferred_date": "2026-11-25",
    "preferred_time": "12:00 PM",
    "duration": 60,
}

result = capstone_workflow.invoke(meeting_request)

print("\n========== CAPSTONE WORKFLOW RESULT ==========")

print("Workflow Status:", result.get("workflow_status"))

print("\nValidation Errors:")
print(result.get("validation_errors"))

print("\nAvailability:")
print(result.get("availability"))

print("\nPrevious Meetings:")
print(len(result.get("previous_meetings", [])))

print("\nPrepared Agenda:")

for item in result.get("agenda", []):
    print(f"- {item['topic']}: {item['minutes']} minutes")

print("\nMessage:")
print(result.get("result_message"))
