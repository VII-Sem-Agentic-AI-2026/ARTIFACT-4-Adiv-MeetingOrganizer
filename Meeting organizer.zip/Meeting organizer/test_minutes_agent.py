
from app.agents.minutes.minutes_agent import (
    extract_meeting_information,
    generate_minutes_document
)
from app.agents.minutes.minutes_agent import (
    extract_meeting_information,
    generate_minutes_document,
    review_meeting_minutes
)

sample_state = {
    "meeting_title": "Research Review Meeting",
    "meeting_date": "2026-11-27",
    "participants": ["Dr. Ravi", "Dr. Priya"],

    "meeting_notes": """
Discussion: Research paper submission progress.
Decision: Submit the revised paper by December 10.
Action: Review research paper | Owner: Dr. Ravi | Deadline: 10 December 2026
Action: Check references | Owner: Dr. Priya | Deadline: 12 December 2026
""",

    "discussion_points": [],
    "decisions": [],
    "action_items": [],
    "missing_information": [],

    "minutes_status": "draft",
    "draft_minutes": ""
}


result = extract_meeting_information(sample_state)

sample_state.update(result)

minutes = generate_minutes_document(sample_state)

print("\n" + minutes)
print("\nHUMAN REVIEW TEST")

review_result = review_meeting_minutes(
    sample_state,
    decision="approved",
    reviewer="Faculty Reviewer"
)

print(review_result)
print("\nREJECTION TEST")

rejection_result = review_meeting_minutes(
    sample_state,
    decision="rejected",
    reviewer="Faculty Reviewer"
)

print(rejection_result)


print("\nINVALID DECISION TEST")

try:
    review_meeting_minutes(
        sample_state,
        decision="pending",
        reviewer="Faculty Reviewer"
    )
except ValueError as error:
    print("Validation successful:", error)